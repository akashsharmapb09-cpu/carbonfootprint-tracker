import React, { useState, useEffect } from 'react';
import {
  X,
  Plus,
  Car,
  Bus,
  Zap,
  Salad,
  Beef,
  Clock,
  Sparkles,
  CheckCircle,
  AlertCircle,
} from 'lucide-react';
import { ACTIVITY_CONFIGS, ActivityType, CarbonActivity } from '../types';
import { calculateEmissions } from '../utils/calculations';

interface ActivityLoggerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddActivity: (activity: Omit<CarbonActivity, 'id'>) => void;
}

export const ActivityLoggerModal: React.FC<ActivityLoggerModalProps> = ({
  isOpen,
  onClose,
  onAddActivity,
}) => {
  const [selectedType, setSelectedType] = useState<ActivityType>('car');
  const [quantity, setQuantity] = useState<string>('15');
  const [timestamp, setTimestamp] = useState<string>('');
  const [note, setNote] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [showSuccessToast, setShowSuccessToast] = useState(false);

  // Helper to get local ISO string formatted for datetime-local input
  const getNowDateTimeLocal = (): string => {
    const now = new Date();
    const offset = now.getTimezoneOffset();
    const local = new Date(now.getTime() - offset * 60000);
    return local.toISOString().slice(0, 16);
  };

  // Initialize date to current date/time on modal open
  useEffect(() => {
    if (isOpen) {
      setTimestamp(getNowDateTimeLocal());
      setErrorMessage('');
      setShowSuccessToast(false);
      // set sensible default for the selected type
      setQuantity(String(ACTIVITY_CONFIGS[selectedType].defaultQuantity));
    }
  }, [isOpen, selectedType]);

  if (!isOpen) return null;

  const currentConfig = ACTIVITY_CONFIGS[selectedType];
  const numQuantity = parseFloat(quantity);
  const computedEmissions = calculateEmissions(selectedType, isNaN(numQuantity) ? 0 : numQuantity);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Validation: Require valid numerical input > 0
    if (isNaN(numQuantity) || numQuantity <= 0) {
      setErrorMessage('Please enter a valid quantity greater than 0.');
      return;
    }

    if (!timestamp) {
      setErrorMessage('Please select a valid date and time.');
      return;
    }

    setErrorMessage('');

    // Convert datetime-local to standard ISO
    const dateObj = new Date(timestamp);
    const validTimestamp = isNaN(dateObj.getTime()) ? new Date().toISOString() : dateObj.toISOString();

    onAddActivity({
      type: selectedType,
      category: currentConfig.category,
      quantity: Math.round(numQuantity * 100) / 100,
      emissionsKg: computedEmissions,
      timestamp: validTimestamp,
      note: note.trim() ? note.trim() : undefined,
    });

    setShowSuccessToast(true);
    setTimeout(() => {
      onClose();
    }, 400);
  };

  // Preset shortcut pills based on activity type
  const presets: Record<ActivityType, number[]> = {
    car: [5, 15, 30, 60],
    bus: [5, 10, 20, 35],
    electricity: [3, 8, 15, 30],
    veg_meal: [1, 2, 3],
    non_veg_meal: [1, 2, 3],
  };

  const activityOptions: { type: ActivityType; label: string; icon: React.ReactNode; factor: string }[] = [
    { type: 'car', label: 'Car Travel', icon: <Car className="w-5 h-5" />, factor: '0.20 kg / km' },
    { type: 'bus', label: 'Public Transit (Bus)', icon: <Bus className="w-5 h-5" />, factor: '0.08 kg / km' },
    { type: 'electricity', label: 'Electricity Usage', icon: <Zap className="w-5 h-5" />, factor: '0.80 kg / kWh' },
    { type: 'veg_meal', label: 'Vegetarian Meal', icon: <Salad className="w-5 h-5" />, factor: '0.50 kg / meal' },
    { type: 'non_veg_meal', label: 'Non-Vegetarian Meal', icon: <Beef className="w-5 h-5" />, factor: '2.00 kg / meal' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div
        id="activity-logger-modal"
        className="w-full max-w-xl bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-2xl overflow-hidden my-6 animate-in fade-in zoom-in-95 duration-200"
      >
        {/* Header */}
        <div className="px-6 py-4.5 border-b border-slate-100 dark:border-slate-700 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-600 dark:bg-emerald-500 flex items-center justify-center text-white">
              <Plus className="w-4 h-4 stroke-[3]" />
            </div>
            <div>
              <h3 className="font-display font-bold text-base sm:text-lg text-slate-900 dark:text-white">
                Log Carbon Activity
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Track your emissions using fixed conversion factors
              </p>
            </div>
          </div>
          <button
            id="close-log-modal-button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {/* Activity Type Selector */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-2">
              Select Activity Type
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {activityOptions.map((opt) => {
                const isSelected = selectedType === opt.type;
                const config = ACTIVITY_CONFIGS[opt.type];
                return (
                  <button
                    key={opt.type}
                    type="button"
                    id={`select-activity-${opt.type}`}
                    onClick={() => {
                      setSelectedType(opt.type);
                      setQuantity(String(config.defaultQuantity));
                    }}
                    className={`p-3 rounded-xl border text-left flex items-center justify-between transition-all cursor-pointer ${
                      isSelected
                        ? 'border-emerald-500 bg-emerald-50/50 dark:bg-emerald-950/30 text-emerald-950 dark:text-emerald-200 ring-2 ring-emerald-500/20 shadow-xs'
                        : 'border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <span
                        className="p-2 rounded-lg"
                        style={{
                          backgroundColor: isSelected ? config.color : undefined,
                          color: isSelected ? '#ffffff' : undefined,
                        }}
                      >
                        {opt.icon}
                      </span>
                      <div>
                        <div className="text-xs font-bold leading-tight">{opt.label}</div>
                        <div className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">
                          {opt.factor}
                        </div>
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Dynamic Quantity Input & Unit */}
          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700 space-y-3">
            <div className="flex items-center justify-between">
              <label
                htmlFor="activity-quantity-input"
                className="text-xs font-bold text-slate-700 dark:text-slate-200"
              >
                Quantity in {currentConfig.unitLabel}
              </label>
              <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
                Rate: {currentConfig.conversionFactor} kg CO₂ / {currentConfig.unit.replace(/s$/, '')}
              </span>
            </div>

            <div className="relative flex items-center">
              <input
                id="activity-quantity-input"
                type="number"
                step="any"
                min="0.01"
                required
                value={quantity}
                onChange={(e) => {
                  setQuantity(e.target.value);
                  if (errorMessage) setErrorMessage('');
                }}
                placeholder={`Enter ${currentConfig.unit}`}
                className="w-full pl-3.5 pr-20 py-2.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 text-slate-900 dark:text-white text-base font-semibold focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition"
              />
              <span className="absolute right-3 px-2 py-1 rounded-md bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 text-xs font-bold uppercase tracking-wider">
                {currentConfig.unit}
              </span>
            </div>

            {/* Presets */}
            <div className="flex items-center gap-1.5 pt-1">
              <span className="text-[11px] text-slate-400">Quick set:</span>
              <div className="flex flex-wrap gap-1.5">
                {presets[selectedType].map((val) => (
                  <button
                    key={val}
                    type="button"
                    onClick={() => {
                      setQuantity(String(val));
                      if (errorMessage) setErrorMessage('');
                    }}
                    className="px-2 py-0.5 rounded-md text-[11px] font-semibold bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-emerald-500 text-slate-600 dark:text-slate-300 cursor-pointer transition"
                  >
                    {val} {currentConfig.unit}
                  </button>
                ))}
              </div>
            </div>

            {/* Live Emission Calculation Preview */}
            <div className="pt-2 border-t border-slate-200 dark:border-slate-700/80 flex items-center justify-between text-xs">
              <span className="text-slate-500 dark:text-slate-400">Computed Emission:</span>
              <div className="flex items-baseline gap-1">
                <span className="text-[11px] text-slate-400 font-mono">
                  {numQuantity > 0 ? numQuantity : 0} × {currentConfig.conversionFactor} =
                </span>
                <span className="font-display font-bold text-base text-emerald-600 dark:text-emerald-400">
                  {computedEmissions.toFixed(2)}
                </span>
                <span className="text-xs font-semibold text-emerald-700 dark:text-emerald-300">
                  kg CO₂
                </span>
              </div>
            </div>
          </div>

          {/* Date & Time Picker */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label
                htmlFor="activity-timestamp-input"
                className="text-xs font-semibold text-slate-700 dark:text-slate-300"
              >
                Date & Time
              </label>
              <button
                type="button"
                onClick={() => setTimestamp(getNowDateTimeLocal())}
                className="text-[11px] font-semibold text-emerald-600 dark:text-emerald-400 hover:underline cursor-pointer flex items-center gap-1"
              >
                <Clock className="w-3 h-3" />
                Set to Now
              </button>
            </div>
            <input
              id="activity-timestamp-input"
              type="datetime-local"
              required
              value={timestamp}
              onChange={(e) => setTimestamp(e.target.value)}
              className="w-full px-3.5 py-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 text-slate-900 dark:text-white text-xs font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500 transition"
            />
          </div>

          {/* Optional Note / Memo */}
          <div>
            <label
              htmlFor="activity-note-input"
              className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
            >
              Optional Note or Context
            </label>
            <input
              id="activity-note-input"
              type="text"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="e.g., Morning commute to client office, AC high usage"
              maxLength={80}
              className="w-full px-3.5 py-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 text-slate-900 dark:text-white text-xs placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500 transition"
            />
          </div>

          {/* Error message */}
          {errorMessage && (
            <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Footer Actions */}
          <div className="pt-2 flex items-center justify-end gap-3">
            <button
              type="button"
              id="cancel-log-activity-button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              id="submit-log-activity-button"
              disabled={showSuccessToast}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white text-xs sm:text-sm font-semibold shadow-md shadow-emerald-600/25 transition cursor-pointer disabled:opacity-50"
            >
              {showSuccessToast ? (
                <>
                  <CheckCircle className="w-4 h-4" />
                  <span>Activity Logged!</span>
                </>
              ) : (
                <>
                  <Plus className="w-4 h-4 stroke-[2.5]" />
                  <span>Log {computedEmissions.toFixed(2)} kg CO₂</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
