import React, { useState } from 'react';
import {
  Flame,
  Award,
  Trophy,
  CheckCircle2,
  XCircle,
  Clock,
  Sparkles,
  Lock,
  ChevronDown,
  ChevronUp,
  Sprout,
  Leaf,
  ShieldCheck,
  Globe,
  AlertCircle,
  HelpCircle,
} from 'lucide-react';
import { CarbonActivity, StreakBadge, WeekStreakRecord } from '../types';
import { computeWeeklyStreakSummary } from '../utils/calculations';

interface WeeklyGoalStreakTrackerProps {
  activities: CarbonActivity[];
  weeklyTarget: number;
}

export const WeeklyGoalStreakTracker: React.FC<WeeklyGoalStreakTrackerProps> = ({
  activities,
  weeklyTarget,
}) => {
  const [isHistoryExpanded, setIsHistoryExpanded] = useState<boolean>(false);
  const [selectedBadge, setSelectedBadge] = useState<StreakBadge | null>(null);

  const streakSummary = computeWeeklyStreakSummary(activities, weeklyTarget);
  const {
    currentStreak,
    completedStreak,
    isCurrentWeekUnderLimit,
    currentWeekKg,
    currentWeekRemainingKg,
    longestStreak,
    recentWeeks,
    badges,
    nextBadge,
    weeksUntilNextBadge,
  } = streakSummary;

  // Badge Icon mapper
  const getBadgeIcon = (iconName: string, className = 'w-6 h-6') => {
    switch (iconName) {
      case 'Sprout':
        return <Sprout className={className} />;
      case 'Leaf':
        return <Leaf className={className} />;
      case 'Flame':
        return <Flame className={className} />;
      case 'ShieldCheck':
        return <ShieldCheck className={className} />;
      case 'Globe':
        return <Globe className={className} />;
      case 'Award':
      default:
        return <Award className={className} />;
    }
  };

  // Tier color styling
  const getTierStyles = (tier: string, isUnlocked: boolean) => {
    if (!isUnlocked) {
      return {
        cardBg: 'bg-slate-50/70 dark:bg-slate-800/40 border-dashed border-slate-300 dark:border-slate-700 opacity-70',
        badgeBg: 'bg-slate-200 dark:bg-slate-700 text-slate-400 dark:text-slate-500',
        pill: 'bg-slate-100 text-slate-500 dark:bg-slate-800 dark:text-slate-400',
        nameColor: 'text-slate-600 dark:text-slate-400',
      };
    }

    switch (tier) {
      case 'bronze':
        return {
          cardBg: 'bg-amber-50/70 dark:bg-amber-950/30 border-amber-300 dark:border-amber-800/70 shadow-xs',
          badgeBg: 'bg-gradient-to-br from-amber-500 to-amber-700 text-white shadow-sm shadow-amber-500/30',
          pill: 'bg-amber-100 text-amber-800 dark:bg-amber-900/60 dark:text-amber-200 font-semibold',
          nameColor: 'text-amber-900 dark:text-amber-100',
        };
      case 'silver':
        return {
          cardBg: 'bg-slate-50 dark:bg-slate-850 border-slate-300 dark:border-slate-600 shadow-xs',
          badgeBg: 'bg-gradient-to-br from-slate-400 to-slate-600 text-white shadow-sm shadow-slate-400/30',
          pill: 'bg-slate-200 text-slate-800 dark:bg-slate-700 dark:text-slate-200 font-semibold',
          nameColor: 'text-slate-900 dark:text-slate-100',
        };
      case 'gold':
        return {
          cardBg: 'bg-yellow-50/80 dark:bg-yellow-950/30 border-yellow-300 dark:border-yellow-700/80 shadow-xs',
          badgeBg: 'bg-gradient-to-br from-amber-400 to-yellow-600 text-white shadow-sm shadow-yellow-500/30',
          pill: 'bg-yellow-100 text-yellow-900 dark:bg-yellow-900/60 dark:text-yellow-200 font-semibold',
          nameColor: 'text-yellow-950 dark:text-yellow-100',
        };
      case 'platinum':
        return {
          cardBg: 'bg-cyan-50/70 dark:bg-cyan-950/30 border-cyan-300 dark:border-cyan-800/70 shadow-xs',
          badgeBg: 'bg-gradient-to-br from-teal-400 to-cyan-600 text-white shadow-sm shadow-cyan-500/30',
          pill: 'bg-cyan-100 text-cyan-900 dark:bg-cyan-900/60 dark:text-cyan-200 font-semibold',
          nameColor: 'text-cyan-950 dark:text-cyan-100',
        };
      case 'diamond':
        return {
          cardBg: 'bg-sky-50/80 dark:bg-sky-950/30 border-sky-300 dark:border-sky-800/70 shadow-xs',
          badgeBg: 'bg-gradient-to-br from-sky-400 to-indigo-600 text-white shadow-sm shadow-sky-500/30',
          pill: 'bg-sky-100 text-sky-900 dark:bg-sky-900/60 dark:text-sky-200 font-semibold',
          nameColor: 'text-sky-950 dark:text-sky-100',
        };
      case 'legendary':
      default:
        return {
          cardBg: 'bg-emerald-50/80 dark:bg-emerald-950/30 border-emerald-300 dark:border-emerald-800/70 shadow-xs',
          badgeBg: 'bg-gradient-to-br from-emerald-500 to-teal-700 text-white shadow-sm shadow-emerald-500/30',
          pill: 'bg-emerald-100 text-emerald-900 dark:bg-emerald-900/60 dark:text-emerald-200 font-semibold',
          nameColor: 'text-emerald-950 dark:text-emerald-100',
        };
    }
  };

  const unlockedBadgesCount = badges.filter((b) => b.isUnlocked).length;

  return (
    <div
      id="weekly-goal-streak-card"
      className="p-5 sm:p-6 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700/80 shadow-xs"
    >
      {/* Header with Title & Badge Stats */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-5 border-b border-slate-100 dark:border-slate-700/70">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 shrink-0">
            <Flame className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-display font-bold text-base sm:text-lg text-slate-900 dark:text-white">
                Weekly Goal Streak & Badges
              </h3>
              {currentStreak > 0 && (
                <span
                  id="active-streak-chip"
                  className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-900 dark:bg-amber-950/80 dark:text-amber-200 border border-amber-200 dark:border-amber-800"
                >
                  <Flame className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
                  {currentStreak} {currentStreak === 1 ? 'Week Streak' : 'Weeks Streak'}
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Stay within your weekly target ({weeklyTarget} kg CO₂) to maintain your streak and earn eco awards
            </p>
          </div>
        </div>

        {/* Counter Summary Pills */}
        <div className="flex items-center gap-2 self-start sm:self-auto">
          <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-900/60 text-xs text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
            <Trophy className="w-3.5 h-3.5 text-amber-500" />
            <span className="font-semibold">Best:</span> {longestStreak}{' '}
            {longestStreak === 1 ? 'Week' : 'Weeks'}
          </span>
          <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-900/60 text-xs text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
            <Award className="w-3.5 h-3.5 text-emerald-500" />
            <span className="font-semibold">Badges:</span> {unlockedBadgesCount} / {badges.length}
          </span>
        </div>
      </div>

      {/* Main Showcase: Big Streak Counter + Current Week Status + Next Reward Progress */}
      <div className="py-5 grid grid-cols-1 md:grid-cols-12 gap-5 items-stretch">
        {/* Left: Flame Counter Block (4 cols) */}
        <div
          id="streak-counter-box"
          className="md:col-span-4 p-5 rounded-xl bg-gradient-to-br from-amber-50/80 via-white to-orange-50/50 dark:from-amber-950/20 dark:via-slate-800 dark:to-orange-950/20 border border-amber-200/80 dark:border-amber-900/60 flex flex-col justify-between"
        >
          <div>
            <div className="flex items-center justify-between text-xs text-amber-800 dark:text-amber-300 font-semibold mb-1">
              <span className="uppercase tracking-wider text-[10px]">Consecutive Goal Success</span>
              <span className="flex items-center gap-1 text-[11px]">
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                Live Tracker
              </span>
            </div>

            <div className="flex items-baseline gap-2 mt-2">
              <span
                id="streak-number-display"
                className="font-display font-extrabold text-4xl sm:text-5xl text-amber-600 dark:text-amber-400 tracking-tight"
              >
                {currentStreak}
              </span>
              <div className="flex flex-col">
                <span className="font-display font-bold text-base text-slate-800 dark:text-slate-200">
                  {currentStreak === 1 ? 'Week' : 'Weeks'}
                </span>
                <span className="text-[11px] text-slate-500 dark:text-slate-400">
                  {currentStreak > 0 ? 'Consistent savings' : 'Build your run!'}
                </span>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-amber-200/60 dark:border-amber-900/60 text-xs">
            {currentStreak > 0 ? (
              <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                🎉 Awesome consistency! You have met or stayed under your carbon limit for{' '}
                <strong className="text-amber-700 dark:text-amber-300">
                  {completedStreak} completed {completedStreak === 1 ? 'week' : 'weeks'}
                </strong>{' '}
                {isCurrentWeekUnderLimit && 'and are on track this active week.'}
              </p>
            ) : (
              <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                Stay under your {weeklyTarget} kg limit through Sunday to claim your first streak milestone badge!
              </p>
            )}
          </div>
        </div>

        {/* Right: Active Week Status & Next Unlock Progress (8 cols) */}
        <div className="md:col-span-8 flex flex-col justify-between space-y-4">
          {/* Active Week Live Status */}
          <div
            id="active-week-status-banner"
            className={`p-4 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
              isCurrentWeekUnderLimit
                ? 'bg-emerald-50/70 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-100'
                : 'bg-rose-50/70 dark:bg-rose-950/30 border-rose-200 dark:border-rose-800 text-rose-900 dark:text-rose-100'
            }`}
          >
            <div className="flex items-start gap-3">
              <div
                className={`p-2 rounded-lg mt-0.5 shrink-0 ${
                  isCurrentWeekUnderLimit
                    ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900 dark:text-emerald-300'
                    : 'bg-rose-100 text-rose-700 dark:bg-rose-900 dark:text-rose-300'
                }`}
              >
                {isCurrentWeekUnderLimit ? (
                  <CheckCircle2 className="w-4 h-4" />
                ) : (
                  <AlertCircle className="w-4 h-4" />
                )}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-xs uppercase tracking-wider">
                    Current Week Progress
                  </span>
                  <span
                    className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${
                      isCurrentWeekUnderLimit
                        ? 'bg-emerald-200/80 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-200'
                        : 'bg-rose-200/80 text-rose-800 dark:bg-rose-900 dark:text-rose-200'
                    }`}
                  >
                    {isCurrentWeekUnderLimit ? 'Streak Active & Protected' : 'Streak Paused'}
                  </span>
                </div>
                <p className="text-xs mt-1 leading-normal">
                  {isCurrentWeekUnderLimit ? (
                    <>
                      Logged <strong>{currentWeekKg.toFixed(1)} kg</strong> of your {weeklyTarget} kg limit.{' '}
                      You have{' '}
                      <strong className="text-emerald-700 dark:text-emerald-300">
                        {currentWeekRemainingKg.toFixed(1)} kg CO₂
                      </strong>{' '}
                      buffer remaining to finish the week and extend your streak.
                    </>
                  ) : (
                    <>
                      Exceeded weekly limit by{' '}
                      <strong>{(currentWeekKg - weeklyTarget).toFixed(1)} kg</strong>. Keep logging to
                      start your rebound next calendar week!
                    </>
                  )}
                </p>
              </div>
            </div>

            <div className="text-right sm:text-right shrink-0">
              <span className="block text-[11px] text-slate-500 dark:text-slate-400">Current Week</span>
              <span className="font-display font-bold text-base text-slate-900 dark:text-white">
                {currentWeekKg.toFixed(1)} / {weeklyTarget} kg
              </span>
            </div>
          </div>

          {/* Next Badge Milestone Card */}
          {nextBadge ? (
            <div
              id="next-badge-progress-card"
              className="p-4 rounded-xl bg-slate-50 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-700/80 flex flex-col justify-between"
            >
              <div className="flex items-center justify-between gap-2 mb-2">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 rounded-lg bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300">
                    <Award className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-xs text-slate-500 dark:text-slate-400">Next Unlockable Badge:</span>
                    <span className="ml-1 text-xs font-bold text-slate-900 dark:text-white">
                      {nextBadge.name} ({nextBadge.requiredWeeks} Weeks)
                    </span>
                  </div>
                </div>
                <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 font-display">
                  {weeksUntilNextBadge} {weeksUntilNextBadge === 1 ? 'week to go' : 'weeks to go'}
                </span>
              </div>

              {/* Progress Bar towards next badge */}
              <div className="space-y-1 mt-1">
                <div className="w-full h-2 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
                  <div
                    className="h-full rounded-full bg-gradient-to-r from-amber-500 to-emerald-500 transition-all duration-500"
                    style={{
                      width: `${Math.min(100, Math.round((currentStreak / nextBadge.requiredWeeks) * 100))}%`,
                    }}
                  />
                </div>
                <div className="flex justify-between text-[11px] text-slate-500 dark:text-slate-400">
                  <span>Current: {currentStreak} weeks</span>
                  <span>Goal: {nextBadge.requiredWeeks} consecutive weeks</span>
                </div>
              </div>
            </div>
          ) : (
            <div className="p-4 rounded-xl bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 text-xs text-emerald-900 dark:text-emerald-100 flex items-center gap-2">
              <Trophy className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>
                <strong>All badges unlocked!</strong> You have achieved legendary status as a Master of Balance. Maintain your streak!
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Badges Grid (Badge Cabinet / Reward Showcase) */}
      <div className="pt-4 border-t border-slate-100 dark:border-slate-700/70">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Award className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            <h4 className="font-display font-bold text-sm text-slate-800 dark:text-slate-200">
              Badge Cabinet & Environmental Achievements
            </h4>
          </div>
          <span className="text-xs text-slate-500 dark:text-slate-400">
            Click any badge to view criteria
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {badges.map((badge) => {
            const styles = getTierStyles(badge.tier, badge.isUnlocked);
            const isSelected = selectedBadge?.id === badge.id;

            return (
              <button
                key={badge.id}
                id={`badge-card-${badge.id}`}
                type="button"
                onClick={() => setSelectedBadge(isSelected ? null : badge)}
                className={`p-3.5 rounded-xl border text-center flex flex-col items-center justify-between transition-all duration-200 cursor-pointer relative group ${
                  styles.cardBg
                } ${isSelected ? 'ring-2 ring-emerald-500 shadow-md scale-[1.02]' : 'hover:scale-[1.01]'}`}
              >
                {/* Unlocked / Locked Indicator Pin */}
                <div className="w-full flex justify-between items-center mb-2">
                  <span className={`text-[10px] px-1.5 py-0.5 rounded ${styles.pill}`}>
                    {badge.requiredWeeks}w
                  </span>
                  {badge.isUnlocked ? (
                    <span className="p-1 rounded-full bg-emerald-100 dark:bg-emerald-900 text-emerald-600 dark:text-emerald-300 shadow-2xs">
                      <CheckCircle2 className="w-3 h-3" />
                    </span>
                  ) : (
                    <span className="p-1 rounded-full bg-slate-100 dark:bg-slate-700 text-slate-400">
                      <Lock className="w-3 h-3" />
                    </span>
                  )}
                </div>

                {/* Badge Icon Emblem */}
                <div
                  className={`w-12 h-12 rounded-2xl flex items-center justify-center my-1 transition-transform group-hover:scale-105 ${styles.badgeBg}`}
                >
                  {getBadgeIcon(badge.icon, 'w-6 h-6')}
                </div>

                {/* Name & Tier */}
                <div className="mt-2 text-center w-full">
                  <span className={`block font-display font-bold text-xs leading-tight ${styles.nameColor}`}>
                    {badge.name}
                  </span>
                  <span className="block text-[10px] text-slate-500 dark:text-slate-400 capitalize mt-0.5">
                    {badge.tier} tier
                  </span>
                </div>

                {/* Status bar / Unlocked stamp */}
                <div className="mt-2 w-full pt-1.5 border-t border-slate-200/50 dark:border-slate-700/50 text-[10px]">
                  {badge.isUnlocked ? (
                    <span className="font-semibold text-emerald-600 dark:text-emerald-400 flex items-center justify-center gap-0.5">
                      <Sparkles className="w-2.5 h-2.5" /> Earned
                    </span>
                  ) : (
                    <span className="text-slate-400">
                      {Math.max(0, badge.requiredWeeks - currentStreak)}w away
                    </span>
                  )}
                </div>
              </button>
            );
          })}
        </div>

        {/* Badge Details Drawer (when a badge is clicked) */}
        {selectedBadge && (
          <div
            id="badge-details-drawer"
            className="mt-4 p-4 rounded-xl bg-slate-50 dark:bg-slate-900/70 border border-slate-200 dark:border-slate-700 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 animate-in fade-in duration-200"
          >
            <div className="flex items-center gap-3">
              <div
                className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 ${
                  getTierStyles(selectedBadge.tier, selectedBadge.isUnlocked).badgeBg
                }`}
              >
                {getBadgeIcon(selectedBadge.icon, 'w-6 h-6')}
              </div>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <h5 className="font-display font-bold text-sm text-slate-900 dark:text-white">
                    {selectedBadge.name}
                  </h5>
                  <span className={`text-[10px] px-2 py-0.5 rounded capitalize ${getTierStyles(selectedBadge.tier, selectedBadge.isUnlocked).pill}`}>
                    {selectedBadge.tier} Tier
                  </span>
                  <span
                    className={`text-[11px] font-semibold px-2 py-0.5 rounded-full ${
                      selectedBadge.isUnlocked
                        ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                        : 'bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-400'
                    }`}
                  >
                    {selectedBadge.isUnlocked ? 'Unlocked & Active' : 'Locked — In Progress'}
                  </span>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-300 mt-1">
                  {selectedBadge.description}
                </p>
                <div className="text-[11px] text-slate-400 mt-0.5">
                  Requirement: Stay within weekly limit ({weeklyTarget} kg CO₂) for {selectedBadge.requiredWeeks} consecutive weeks.
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setSelectedBadge(null)}
              className="self-end sm:self-auto px-3 py-1 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white bg-slate-200 dark:bg-slate-750 hover:bg-slate-300 dark:hover:bg-slate-700 rounded-lg transition cursor-pointer"
            >
              Close Details
            </button>
          </div>
        )}
      </div>

      {/* Collapsible Section: Past Weeks Goal Audit History */}
      <div className="mt-5 pt-4 border-t border-slate-100 dark:border-slate-700/70">
        <button
          id="toggle-streak-audit-history"
          type="button"
          onClick={() => setIsHistoryExpanded(!isHistoryExpanded)}
          className="w-full flex items-center justify-between text-xs font-semibold text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white py-1 cursor-pointer"
          aria-expanded={isHistoryExpanded}
        >
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-slate-400" />
            <span>Weekly Target Audit History (Past 8 Weeks)</span>
            <span className="text-[11px] text-slate-400 font-normal">
              — Review pass/fail records that count toward your streak
            </span>
          </div>
          <div className="flex items-center gap-1 text-slate-500">
            <span>{isHistoryExpanded ? 'Hide History' : 'View History'}</span>
            {isHistoryExpanded ? (
              <ChevronUp className="w-4 h-4" />
            ) : (
              <ChevronDown className="w-4 h-4" />
            )}
          </div>
        </button>

        {isHistoryExpanded && (
          <div
            id="streak-audit-history-panel"
            className="mt-3 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 animate-in fade-in duration-200"
          >
            {recentWeeks.map((week) => {
              const isCurrent = week.isCurrentWeek;
              const hasActivities = week.activitiesCount > 0;

              return (
                <div
                  key={week.weekOffset}
                  className={`p-3 rounded-xl border flex flex-col justify-between text-xs ${
                    isCurrent
                      ? 'bg-sky-50/50 dark:bg-sky-950/20 border-sky-300 dark:border-sky-800'
                      : week.isUnderLimit
                      ? 'bg-emerald-50/50 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-900/60'
                      : 'bg-rose-50/50 dark:bg-rose-950/20 border-rose-200 dark:border-rose-900/60'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-semibold text-slate-700 dark:text-slate-300">
                      {isCurrent ? 'This Week' : week.weekOffset === 1 ? 'Last Week' : `${week.weekOffset}w Ago`}
                    </span>
                    <span
                      className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        isCurrent
                          ? 'bg-sky-100 text-sky-800 dark:bg-sky-900 dark:text-sky-200'
                          : week.isUnderLimit
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-200'
                          : 'bg-rose-100 text-rose-800 dark:bg-rose-900 dark:text-rose-200'
                      }`}
                    >
                      {isCurrent ? (
                        <>
                          <Clock className="w-3 h-3" /> In Progress
                        </>
                      ) : week.isUnderLimit ? (
                        <>
                          <CheckCircle2 className="w-3 h-3" /> Goal Met
                        </>
                      ) : (
                        <>
                          <XCircle className="w-3 h-3" /> Exceeded
                        </>
                      )}
                    </span>
                  </div>

                  <div>
                    <div className="flex items-baseline justify-between">
                      <span className="text-[11px] text-slate-500 dark:text-slate-400">
                        {week.label}
                      </span>
                      <span
                        className={`font-display font-bold ${
                          week.isUnderLimit
                            ? 'text-emerald-700 dark:text-emerald-400'
                            : 'text-rose-700 dark:text-rose-400'
                        }`}
                      >
                        {week.totalEmissionsKg.toFixed(1)} kg
                      </span>
                    </div>

                    <div className="flex justify-between items-center text-[10px] text-slate-400 mt-1 pt-1.5 border-t border-slate-200/50 dark:border-slate-700/50">
                      <span>Limit: {week.targetKg} kg</span>
                      <span>{hasActivities ? `${week.activitiesCount} logs` : 'No logs'}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
