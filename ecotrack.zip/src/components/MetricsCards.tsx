import React, { useRef, useEffect } from 'react';
import { motion, useAnimationControls } from 'motion/react';
import {
  Globe,
  CalendarDays,
  TrendingUp,
  TreePine,
  Activity,
  Layers,
} from 'lucide-react';
import { DashboardMetrics } from '../utils/calculations';

interface MetricsCardsProps {
  metrics: DashboardMetrics;
  totalActivitiesCount: number;
}

interface AnimatedMetricCardProps {
  id: string;
  triggerValue: any;
  children: React.ReactNode;
  className?: string;
}

const AnimatedMetricCard: React.FC<AnimatedMetricCardProps> = ({
  id,
  triggerValue,
  children,
  className = '',
}) => {
  const controls = useAnimationControls();
  const isFirstRender = useRef(true);

  useEffect(() => {
    if (isFirstRender.current) {
      isFirstRender.current = false;
      return;
    }
    // Scale animation triggered on value update
    controls.start({
      scale: [1, 1.035, 0.995, 1],
      transition: { duration: 0.38, ease: [0.25, 1, 0.5, 1] },
    });
  }, [triggerValue, controls]);

  return (
    <motion.div
      id={id}
      animate={controls}
      className={className}
    >
      {children}
    </motion.div>
  );
};

export const MetricsCards: React.FC<MetricsCardsProps> = ({
  metrics,
  totalActivitiesCount,
}) => {
  // Find category with highest emissions
  const topCategory = [...metrics.categoryBreakdown].sort((a, b) => b.totalKg - a.totalKg)[0];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {/* Metric 1: Total Lifetime CO2 */}
      <AnimatedMetricCard
        id="metric-lifetime-card"
        triggerValue={`${metrics.totalLifetimeKg}-${totalActivitiesCount}`}
        className="p-5 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700/80 shadow-xs flex flex-col justify-between"
      >
        <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-2">
          <span className="text-xs font-semibold uppercase tracking-wider">Total Lifetime CO₂</span>
          <div className="p-2 rounded-xl bg-slate-100 dark:bg-slate-700/60 text-slate-700 dark:text-slate-200">
            <Globe className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
          </div>
        </div>
        <div>
          <div className="flex items-baseline gap-1.5">
            <motion.span
              key={metrics.totalLifetimeKg}
              initial={{ scale: 0.94, opacity: 0.8 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.25, ease: 'easeOut' }}
              className="font-display font-bold text-2xl sm:text-3xl text-slate-900 dark:text-white tracking-tight"
            >
              {metrics.totalLifetimeKg.toLocaleString(undefined, { minimumFractionDigits: 1, maximumFractionDigits: 2 })}
            </motion.span>
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">kg CO₂</span>
          </div>
          <div className="flex items-center gap-1 text-[11px] text-slate-500 dark:text-slate-400 mt-2">
            <Activity className="w-3.5 h-3.5 text-emerald-500" />
            <span>Across {totalActivitiesCount} logged entries</span>
          </div>
        </div>
      </AnimatedMetricCard>

      {/* Metric 2: Current Week Total */}
      <AnimatedMetricCard
        id="metric-current-week-card"
        triggerValue={`${metrics.currentWeekKg}-${metrics.activeWeekPercentage}`}
        className="p-5 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700/80 shadow-xs flex flex-col justify-between"
      >
        <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-2">
          <span className="text-xs font-semibold uppercase tracking-wider">Current Week CO₂</span>
          <div className="p-2 rounded-xl bg-slate-100 dark:bg-slate-700/60 text-slate-700 dark:text-slate-200">
            <CalendarDays className="w-4 h-4 text-sky-600 dark:text-sky-400" />
          </div>
        </div>
        <div>
          <div className="flex items-baseline gap-1.5">
            <motion.span
              key={metrics.currentWeekKg}
              initial={{ scale: 0.94, opacity: 0.8 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.25, ease: 'easeOut' }}
              className="font-display font-bold text-2xl sm:text-3xl text-slate-900 dark:text-white tracking-tight"
            >
              {metrics.currentWeekKg.toLocaleString(undefined, { minimumFractionDigits: 1, maximumFractionDigits: 2 })}
            </motion.span>
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">kg CO₂</span>
          </div>
          <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 mt-2">
            <span
              className={`font-semibold ${
                metrics.activeWeekPercentage >= 100
                  ? 'text-rose-600 dark:text-rose-400'
                  : metrics.activeWeekPercentage >= 80
                  ? 'text-amber-600 dark:text-amber-400'
                  : 'text-emerald-600 dark:text-emerald-400'
              }`}
            >
              {metrics.activeWeekPercentage}% of weekly budget
            </span>
            <span>{metrics.daysRemainingInWeek} days left</span>
          </div>
        </div>
      </AnimatedMetricCard>

      {/* Metric 3: Daily Average Emissions */}
      <AnimatedMetricCard
        id="metric-daily-average-card"
        triggerValue={metrics.dailyAverageKg}
        className="p-5 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700/80 shadow-xs flex flex-col justify-between"
      >
        <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-2">
          <span className="text-xs font-semibold uppercase tracking-wider">Daily Average</span>
          <div className="p-2 rounded-xl bg-slate-100 dark:bg-slate-700/60 text-slate-700 dark:text-slate-200">
            <TrendingUp className="w-4 h-4 text-amber-600 dark:text-amber-400" />
          </div>
        </div>
        <div>
          <div className="flex items-baseline gap-1.5">
            <motion.span
              key={metrics.dailyAverageKg}
              initial={{ scale: 0.94, opacity: 0.8 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.25, ease: 'easeOut' }}
              className="font-display font-bold text-2xl sm:text-3xl text-slate-900 dark:text-white tracking-tight"
            >
              {metrics.dailyAverageKg.toLocaleString(undefined, { minimumFractionDigits: 1, maximumFractionDigits: 2 })}
            </motion.span>
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">kg / day</span>
          </div>
          <div className="flex items-center gap-1 text-[11px] text-slate-500 dark:text-slate-400 mt-2">
            <span>Based on {metrics.activeDaysCount} active recording days</span>
          </div>
        </div>
      </AnimatedMetricCard>

      {/* Metric 4: Primary Impact Driver & Tree Offset */}
      <AnimatedMetricCard
        id="metric-impact-insight-card"
        triggerValue={`${topCategory?.totalKg}-${metrics.treesEquivalent}`}
        className="p-5 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700/80 shadow-xs flex flex-col justify-between"
      >
        <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 mb-2">
          <span className="text-xs font-semibold uppercase tracking-wider">Top Emission Source</span>
          <div className="p-2 rounded-xl bg-slate-100 dark:bg-slate-700/60 text-slate-700 dark:text-slate-200">
            <Layers className="w-4 h-4 text-teal-600 dark:text-teal-400" />
          </div>
        </div>
        <div>
          <div className="flex items-baseline gap-1.5">
            <span className="font-display font-bold text-xl sm:text-2xl text-slate-900 dark:text-white tracking-tight truncate">
              {topCategory && topCategory.totalKg > 0 ? topCategory.label.split(' ')[0] : 'None'}
            </span>
            {topCategory && topCategory.totalKg > 0 && (
              <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400">
                ({topCategory.percentage}%)
              </span>
            )}
          </div>
          <div className="flex items-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400 mt-2">
            <TreePine className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
            <span>~{metrics.treesEquivalent} urban trees/year to absorb</span>
          </div>
        </div>
      </AnimatedMetricCard>
    </div>
  );
};
