import React, { useState } from 'react';
import {
  Car,
  Zap,
  Salad,
  PieChart as PieChartIcon,
  BarChart3,
  Lightbulb,
  ArrowRight,
} from 'lucide-react';
import { CarbonActivity, ActivityCategory } from '../types';
import { DashboardMetrics, getWeeklyDailyDistribution } from '../utils/calculations';
import { WeeklyComparisonChart } from './WeeklyComparisonChart';
import { MonthlyEmissionTrendChart } from './MonthlyEmissionTrendChart';

interface VisualAnalyticsProps {
  metrics: DashboardMetrics;
  activities: CarbonActivity[];
  weeklyTarget: number;
}

export const VisualAnalytics: React.FC<VisualAnalyticsProps> = ({
  metrics,
  activities,
  weeklyTarget,
}) => {
  const [hoveredCategory, setHoveredCategory] = useState<ActivityCategory | null>(null);

  // 7-day distribution
  const weekDays = getWeeklyDailyDistribution(activities);
  const maxDayKg = Math.max(5, ...weekDays.map((d) => d.totalKg));

  // Category icons mapping
  const categoryIcons: Record<ActivityCategory, React.ReactNode> = {
    travel: <Car className="w-4 h-4" />,
    energy: <Zap className="w-4 h-4" />,
    food: <Salad className="w-4 h-4" />,
  };

  // Build SVG Donut Chart Slices
  const totalKg = metrics.totalLifetimeKg;
  const radius = 64;
  const circumference = 2 * Math.PI * radius;
  let accumulatedOffset = 0;

  const slices = metrics.categoryBreakdown.map((cat) => {
    const fraction = totalKg > 0 ? cat.totalKg / totalKg : 0;
    const strokeDasharray = `${fraction * circumference} ${circumference}`;
    const strokeDashoffset = -accumulatedOffset;
    accumulatedOffset += fraction * circumference;

    return {
      ...cat,
      fraction,
      strokeDasharray,
      strokeDashoffset,
    };
  });

  const activeFocus = hoveredCategory
    ? metrics.categoryBreakdown.find((c) => c.category === hoveredCategory)
    : null;

  // Contextual carbon saving tip based on highest category
  const topCat = [...metrics.categoryBreakdown].sort((a, b) => b.totalKg - a.totalKg)[0];
  let tipText = 'Log regular daily activities to discover your highest emission opportunities.';
  if (topCat && topCat.totalKg > 0) {
    if (topCat.category === 'travel') {
      tipText =
        'Travel is currently your top emission source. Replacing a 10 km car commute with the bus saves 1.2 kg CO₂ each trip!';
    } else if (topCat.category === 'energy') {
      tipText =
        'Electricity is your top emission driver (0.80 kg CO₂/kWh). Turning off idle electronics and optimizing cooling/heating will quickly lower your footprint.';
    } else if (topCat.category === 'food') {
      tipText =
        'Food is your leading emission category. Non-vegetarian meals produce 2.0 kg CO₂ compared to 0.5 kg for plant-based meals—swapping one meal a day cuts emissions by 75%!';
    }
  }

  return (
    <div className="space-y-6">
      {/* Week-over-Week Emissions Comparison Chart */}
      <WeeklyComparisonChart activities={activities} weeklyTarget={weeklyTarget} />

      {/* Breakdown by Category & Daily Cadence Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left / Middle: Category Breakdown (Donut + Progress) - 7 cols on LG */}
        <div
          id="category-breakdown-panel"
          className="lg:col-span-7 p-6 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700/80 shadow-xs flex flex-col justify-between"
        >
        <div>
          <div className="flex items-center justify-between mb-5">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400">
                <PieChartIcon className="w-4 h-4" />
              </div>
              <div>
                <h3 className="font-display font-bold text-base sm:text-lg text-slate-900 dark:text-white">
                  Emissions by Category
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Percentage and absolute CO₂ contribution
                </p>
              </div>
            </div>
            <span className="text-xs font-medium px-2.5 py-1 rounded-full bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300">
              Lifetime: {totalKg.toFixed(1)} kg
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-12 gap-6 items-center">
            {/* Donut Chart SVG */}
            <div className="sm:col-span-5 flex flex-col items-center justify-center relative py-2">
              <div className="relative w-44 h-44 flex items-center justify-center">
                <svg
                  className="w-full h-full -rotate-90 transform"
                  viewBox="0 0 160 160"
                  aria-label="Carbon emission category donut chart"
                >
                  {/* Background Track */}
                  <circle
                    cx="80"
                    cy="80"
                    r={radius}
                    className="stroke-slate-100 dark:stroke-slate-700"
                    strokeWidth="18"
                    fill="transparent"
                  />

                  {/* Slices */}
                  {totalKg > 0 ? (
                    slices.map((slice) => (
                      <circle
                        key={slice.category}
                        cx="80"
                        cy="80"
                        r={radius}
                        stroke={slice.color}
                        strokeWidth={hoveredCategory === slice.category ? 22 : 18}
                        strokeDasharray={slice.strokeDasharray}
                        strokeDashoffset={slice.strokeDashoffset}
                        strokeLinecap="round"
                        fill="transparent"
                        className="transition-all duration-300 cursor-pointer"
                        onMouseEnter={() => setHoveredCategory(slice.category)}
                        onMouseLeave={() => setHoveredCategory(null)}
                      />
                    ))
                  ) : (
                    <circle
                      cx="80"
                      cy="80"
                      r={radius}
                      className="stroke-slate-200 dark:stroke-slate-700"
                      strokeWidth="18"
                      strokeDasharray="4 4"
                      fill="transparent"
                    />
                  )}
                </svg>

                {/* Center Content */}
                <div className="absolute inset-0 flex flex-col items-center justify-center text-center pointer-events-none px-3">
                  {activeFocus ? (
                    <>
                      <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 capitalize">
                        {activeFocus.category}
                      </span>
                      <span className="font-display font-bold text-xl text-slate-900 dark:text-white">
                        {activeFocus.percentage}%
                      </span>
                      <span className="text-[10px] text-slate-500 dark:text-slate-400">
                        {activeFocus.totalKg.toFixed(1)} kg CO₂
                      </span>
                    </>
                  ) : (
                    <>
                      <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                        Total CO₂
                      </span>
                      <span className="font-display font-bold text-xl text-slate-900 dark:text-white">
                        {totalKg.toFixed(1)}
                      </span>
                      <span className="text-[10px] text-slate-500 dark:text-slate-400">Kilograms</span>
                    </>
                  )}
                </div>
              </div>

              <span className="text-[11px] text-slate-400 mt-2 text-center">
                Hover slice to inspect details
              </span>
            </div>

            {/* Category Breakdown Progress Bars */}
            <div className="sm:col-span-7 space-y-4">
              {metrics.categoryBreakdown.map((cat) => {
                const isHovered = hoveredCategory === cat.category;
                return (
                  <div
                    key={cat.category}
                    id={`breakdown-row-${cat.category}`}
                    onMouseEnter={() => setHoveredCategory(cat.category)}
                    onMouseLeave={() => setHoveredCategory(null)}
                    className={`p-3 rounded-xl border transition-all cursor-pointer ${
                      isHovered
                        ? 'bg-slate-50 dark:bg-slate-700/50 border-slate-300 dark:border-slate-600 shadow-xs'
                        : 'bg-transparent border-transparent hover:bg-slate-50/60 dark:hover:bg-slate-800/60'
                    }`}
                  >
                    <div className="flex items-center justify-between text-xs mb-1.5">
                      <div className="flex items-center gap-2">
                        <span
                          className="p-1.5 rounded-lg text-white"
                          style={{ backgroundColor: cat.color }}
                        >
                          {categoryIcons[cat.category]}
                        </span>
                        <div>
                          <span className="font-semibold text-slate-800 dark:text-slate-200">
                            {cat.label}
                          </span>
                          <span className="block text-[10px] text-slate-400">
                            {cat.count} {cat.count === 1 ? 'activity' : 'activities'} logged
                          </span>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className="font-display font-bold text-sm text-slate-900 dark:text-white">
                          {cat.totalKg.toFixed(2)} kg
                        </span>
                        <span className="block text-[11px] font-semibold" style={{ color: cat.color }}>
                          {cat.percentage}%
                        </span>
                      </div>
                    </div>

                    {/* Progress Bar */}
                    <div className="w-full h-2 bg-slate-100 dark:bg-slate-700 rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-300"
                        style={{
                          width: `${cat.percentage}%`,
                          backgroundColor: cat.color,
                        }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Climate Insight Tip */}
        <div className="mt-5 pt-4 border-t border-slate-100 dark:border-slate-700/80 flex items-start gap-2.5 text-xs text-slate-600 dark:text-slate-300 bg-emerald-50/60 dark:bg-emerald-950/20 p-3 rounded-xl border border-emerald-100 dark:border-emerald-900/40">
          <Lightbulb className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
          <p className="leading-relaxed">{tipText}</p>
        </div>
      </div>

      {/* Right: Active Week Daily Cadence (5 cols on LG) */}
      <div
        id="weekly-distribution-panel"
        className="lg:col-span-5 p-6 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700/80 shadow-xs flex flex-col justify-between"
      >
        <div>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-xl bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400">
                <BarChart3 className="w-4 h-4" />
              </div>
              <div>
                <h3 className="font-display font-bold text-base sm:text-lg text-slate-900 dark:text-white">
                  This Week Daily Log
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Monday to Sunday calendar pacing
                </p>
              </div>
            </div>
            <span className="text-[11px] text-slate-500 font-medium">
              Avg cap: {(weeklyTarget / 7).toFixed(1)} kg/day
            </span>
          </div>

          <p className="text-xs text-slate-500 dark:text-slate-400 mb-6">
            Compare daily emission spikes to keep your footprint balanced across the week.
          </p>

          {/* 7-Day Bar Chart */}
          <div className="h-48 flex items-end justify-between gap-2 px-1 pt-4 pb-2 border-b border-slate-100 dark:border-slate-700/80 relative">
            {/* Daily Target Benchmark Line (weeklyTarget / 7) */}
            <div
              className="absolute left-0 right-0 border-b border-dashed border-emerald-400/70 z-0 pointer-events-none"
              style={{
                bottom: `${Math.min(95, Math.max(10, ((weeklyTarget / 7) / maxDayKg) * 100))}%`,
              }}
            >
              <span className="absolute right-0 -top-4 text-[9px] font-semibold text-emerald-600 dark:text-emerald-400 bg-white/90 dark:bg-slate-800/90 px-1 rounded">
                Target Cap: {(weeklyTarget / 7).toFixed(1)} kg
              </span>
            </div>

            {weekDays.map((day) => {
              const heightPercent = maxDayKg > 0 ? Math.min(100, Math.round((day.totalKg / maxDayKg) * 100)) : 0;
              const isOverDailyCap = day.totalKg > weeklyTarget / 7;

              return (
                <div
                  key={day.dateStr}
                  className="flex-1 flex flex-col items-center h-full justify-end group relative z-10"
                >
                  {/* Tooltip on hover */}
                  <div className="opacity-0 group-hover:opacity-100 transition-opacity absolute -top-9 bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900 text-[10px] font-semibold px-2 py-1 rounded shadow pointer-events-none whitespace-nowrap z-20">
                    {day.totalKg.toFixed(2)} kg CO₂
                  </div>

                  {/* Bar */}
                  <div className="w-full max-w-[28px] h-full flex items-end">
                    <div
                      className={`w-full rounded-t-md transition-all duration-300 ${
                        day.isToday
                          ? 'bg-emerald-500 dark:bg-emerald-400 ring-2 ring-emerald-300 dark:ring-emerald-700'
                          : isOverDailyCap
                          ? 'bg-amber-400 dark:bg-amber-500'
                          : day.totalKg > 0
                          ? 'bg-sky-500/80 dark:bg-sky-500/70'
                          : 'bg-slate-100 dark:bg-slate-700/60'
                      }`}
                      style={{ height: `${Math.max(6, heightPercent)}%` }}
                    />
                  </div>

                  {/* Day Label */}
                  <div className="mt-2 text-center">
                    <span
                      className={`block text-[11px] font-semibold ${
                        day.isToday
                          ? 'text-emerald-600 dark:text-emerald-400'
                          : 'text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      {day.dayName}
                    </span>
                    <span className="block text-[9px] text-slate-400">
                      {day.shortDate}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Legend */}
        <div className="mt-4 pt-3 flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-500 dark:text-slate-400">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded bg-emerald-500"></span>
              <span>Today</span>
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded bg-sky-500"></span>
              <span>Logged</span>
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded bg-amber-400"></span>
              <span>Over Cap</span>
            </span>
          </div>
          <span className="text-[10px] text-slate-400">
            Total week: {metrics.currentWeekKg.toFixed(1)} kg
          </span>
        </div>
      </div>
    </div>

    {/* Section: Annual & Monthly CO2 Emission Trends */}
    <MonthlyEmissionTrendChart activities={activities} weeklyTarget={weeklyTarget} />
  </div>
  );
};
