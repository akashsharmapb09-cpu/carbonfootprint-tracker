import React, { useState } from 'react';
import { Target, X, Check, Sparkles, AlertCircle } from 'lucide-react';

interface TargetModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentTarget: number;
  onSaveTarget: (newTarget: number) => void;
}

export const TargetModal: React.FC<TargetModalProps> = ({
  isOpen,
  onClose,
  currentTarget,
  onSaveTarget,
}) => {
  const [targetInput, setTargetInput] = useState<string>(String(currentTarget));
  const [error, setError] = useState<string>('');

  if (!isOpen) return null;

  const num = parseFloat(targetInput);

  const presets = [
    {
      value: 30,
      title: 'Eco-Champion (30 kg)',
      desc: 'Plant-forward diet, active public transit, ~4.3 kg/day',
      tag: 'Ambitious',
    },
    {
      value: 50,
      title: 'Standard Sustainable (50 kg)',
      desc: 'Balanced commute, energy consciousness, ~7.1 kg/day',
      tag: 'Recommended',
    },
    {
      value: 75,
      title: 'Moderate Budget (75 kg)',
      desc: 'Regular car trips and average home power, ~10.7 kg/day',
      tag: 'Moderate',
    },
    {
      value: 100,
      title: 'Gradual Transition (100 kg)',
      desc: 'Higher commuter mileage or heavy winter heating, ~14.3 kg/day',
      tag: 'Relaxed',
    },
  ];

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (isNaN(num) || num <= 0) {
      setError('Please enter a valid target greater than 0 kg CO₂.');
      return;
    }
    setError('');
    onSaveTarget(Math.round(num * 10) / 10);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div
        id="target-settings-modal"
        className="w-full max-w-md bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-2xl p-6 animate-in fade-in zoom-in-95 duration-150"
      >
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-400">
              <Target className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-display font-bold text-lg text-slate-900 dark:text-white">
                Set Weekly Carbon Limit
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Define your weekly emission ceiling (kg CO₂ / week)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSave} className="space-y-4">
          {/* Custom Input */}
          <div>
            <label
              htmlFor="custom-target-input"
              className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5"
            >
              Custom Target Amount
            </label>
            <div className="relative flex items-center">
              <input
                id="custom-target-input"
                type="number"
                step="1"
                min="5"
                max="5000"
                required
                value={targetInput}
                onChange={(e) => {
                  setTargetInput(e.target.value);
                  if (error) setError('');
                }}
                className="w-full pl-3.5 pr-24 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-300 dark:border-slate-600 text-slate-900 dark:text-white text-base font-bold focus:outline-none focus:ring-2 focus:ring-emerald-500"
              />
              <span className="absolute right-3 px-2 py-0.5 rounded text-xs font-semibold bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300">
                kg CO₂ / wk
              </span>
            </div>
            {num > 0 && (
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-emerald-500" />
                Equivalent daily allowance: ~{(num / 7).toFixed(1)} kg CO₂ per day
              </p>
            )}
          </div>

          {/* Preset Buttons */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2">
              Recommended Benchmarks
            </label>
            <div className="space-y-2">
              {presets.map((p) => {
                const isSelected = num === p.value;
                return (
                  <button
                    key={p.value}
                    type="button"
                    onClick={() => {
                      setTargetInput(String(p.value));
                      if (error) setError('');
                    }}
                    className={`w-full p-3 rounded-xl border text-left flex items-center justify-between transition cursor-pointer ${
                      isSelected
                        ? 'border-emerald-500 bg-emerald-50/60 dark:bg-emerald-950/30 text-emerald-950 dark:text-emerald-200 ring-2 ring-emerald-500/20'
                        : 'border-slate-200 dark:border-slate-700 hover:border-slate-300 dark:hover:border-slate-600 bg-white dark:bg-slate-800'
                    }`}
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-slate-900 dark:text-white">
                          {p.title}
                        </span>
                        <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300">
                          {p.tag}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                        {p.desc}
                      </p>
                    </div>
                    {isSelected && (
                      <Check className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0 ml-2" />
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {error && (
            <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/50 text-rose-700 dark:text-rose-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Buttons */}
          <div className="pt-2 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold shadow-sm transition cursor-pointer"
            >
              Save Target
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
