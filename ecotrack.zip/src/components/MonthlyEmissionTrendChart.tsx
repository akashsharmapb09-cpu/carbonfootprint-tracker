import React, { useState } from 'react';
import {
  CalendarRange,
  TrendingDown,
  TrendingUp,
  Layers,
  Activity,
  Target,
  Car,
  Zap,
  Salad,
  Sparkles,
  Info,
  Calendar,
  ChevronRight,
  CheckCircle2,
  AlertTriangle,
  X,
} from 'lucide-react';
import { CarbonActivity } from '../types';
import { computeMonthlyEmissionTrends } from '../utils/calculations';

interface MonthlyEmissionTrendChartProps {
  activities: CarbonActivity[];
  weeklyTarget: number;
}

type TrendViewMode = 'stacked' | 'area' | 'quarterly';

export const MonthlyEmissionTrendChart: React.FC<MonthlyEmissionTrendChartProps> = ({
  activities,
  weeklyTarget,
}) => {
  const [selectedYear, setSelectedYear] = useState<number>(() => new Date().getFullYear());
  const [viewMode, setViewMode] = useState<TrendViewMode>('stacked');
  const [selectedMonthIndex, setSelectedMonthIndex] = useState<number | null>(() => new Date().getMonth());
  const [hoveredMonthIndex, setHoveredMonthIndex] = useState<number | null>(null);
  const [selectedQuarter, setSelectedQuarter] = useState<string | null>(null);

  // Compute full annual trend metrics
  const annualTrends = computeMonthlyEmissionTrends(activities, weeklyTarget, selectedYear);
  const {
    months,
    quarterly,
    totalYearKg,
    monthlyAverageKg,
    peakMonth,
    lowestActiveMonth,
    availableYears,
    seasonalityInsight,
  } = annualTrends;

  // Selected month detail
  const activeMonthData =
    selectedMonthIndex !== null ? months[selectedMonthIndex] || null : null;

  // Selected quarter detail
  const selectedQuarterData =
    selectedQuarter !== null ? quarterly.find((q) => q.quarter === selectedQuarter) || null : null;

  // Benchmark reference value for 1 month
  const averageMonthlyBudget = Math.round(weeklyTarget * (52 / 12) * 10) / 10;

  // Scale calculations for Stacked / Monthly views
  const maxMonthValue = Math.max(
    averageMonthlyBudget * 1.25,
    ...months.map((m) => m.totalKg),
    20
  );

  // Scale calculations for Quarterly view
  const maxQuarterlyValue = Math.max(
    averageMonthlyBudget * 3 * 1.25,
    ...quarterly.map((q) => q.totalKg),
    40
  );

  // Compute SVG coordinates for Area Chart mode
  const chartSvgWidth = 720;
  const chartSvgHeight = 220;
  const paddingX = 40;
  const paddingY = 24;
  const plotWidth = chartSvgWidth - paddingX * 2;
  const plotHeight = chartSvgHeight - paddingY * 2;

  const points = months.map((m, idx) => {
    const x = paddingX + (idx / 11) * plotWidth;
    const yRatio = maxMonthValue > 0 ? m.totalKg / maxMonthValue : 0;
    const y = chartSvgHeight - paddingY - yRatio * plotHeight;
    return { x, y, month: m };
  });

  // Target budget line Y on SVG
  const budgetRatio = maxMonthValue > 0 ? averageMonthlyBudget / maxMonthValue : 0;
  const budgetLineY = chartSvgHeight - paddingY - budgetRatio * plotHeight;

  // Build SVG smooth path command using Catmull-Rom or cubic Bezier
  const createSmoothPath = (pts: { x: number; y: number }[]) => {
    if (pts.length === 0) return '';
    let d = `M ${pts[0].x} ${pts[0].y}`;
    for (let i = 0; i < pts.length - 1; i++) {
      const p0 = pts[i === 0 ? 0 : i - 1];
      const p1 = pts[i];
      const p2 = pts[i + 1];
      const p3 = pts[i + 2 < pts.length ? i + 2 : i + 1];

      const cp1x = p1.x + (p2.x - p0.x) / 6;
      const cp1y = p1.y + (p2.y - p0.y) / 6;
      const cp2x = p2.x - (p3.x - p1.x) / 6;
      const cp2y = p2.y - (p3.y - p1.y) / 6;

      d += ` C ${cp1x} ${cp1y}, ${cp2x} ${cp2y}, ${p2.x} ${p2.y}`;
    }
    return d;
  };

  const linePath = createSmoothPath(points);
  const areaPath = `${linePath} L ${points[points.length - 1]?.x || plotWidth} ${
    chartSvgHeight - paddingY
  } L ${points[0]?.x || paddingX} ${chartSvgHeight - paddingY} Z`;

  return (
    <div
      id="monthly-emission-trend-panel"
      className="p-6 rounded-2xl bg-white dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700/80 shadow-xs space-y-6"
    >
      {/* Header with Title, Year Selector & View Toggles */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-5 border-b border-slate-100 dark:border-slate-700/70">
        <div className="flex items-start sm:items-center gap-3">
          <div className="p-2.5 rounded-xl bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 shrink-0">
            <CalendarRange className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="font-display font-bold text-base sm:text-lg text-slate-900 dark:text-white">
                Annual & Monthly CO₂ Emission Trends
              </h3>
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-sky-100 text-sky-800 dark:bg-sky-950 dark:text-sky-300 border border-sky-200/80 dark:border-sky-800/80">
                <Activity className="w-3 h-3" />
                Year {annualTrends.year}
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Visualize monthly carbon trajectory, category shifts, and seasonal variance throughout the year
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 self-start sm:self-auto">
          {/* Year Switcher if multiple years exist */}
          {availableYears.length > 1 && (
            <div className="inline-flex items-center p-1 rounded-xl bg-slate-100 dark:bg-slate-900/60 border border-slate-200/70 dark:border-slate-700 text-xs">
              {availableYears.map((yr) => (
                <button
                  key={yr}
                  id={`trend-year-${yr}`}
                  onClick={() => {
                    setSelectedYear(yr);
                    setSelectedMonthIndex(null);
                  }}
                  className={`px-2.5 py-1 rounded-lg font-medium transition cursor-pointer ${
                    selectedYear === yr
                      ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-2xs'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  {yr}
                </button>
              ))}
            </div>
          )}

          {/* Mode Switcher */}
          <div className="inline-flex items-center p-1 rounded-xl bg-slate-100 dark:bg-slate-900/60 border border-slate-200/70 dark:border-slate-700 text-xs">
            <button
              id="trend-view-stacked-btn"
              onClick={() => setViewMode('stacked')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition cursor-pointer ${
                viewMode === 'stacked'
                  ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-2xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
              title="Stacked Category Breakdown"
            >
              <Layers className="w-3.5 h-3.5 text-sky-600 dark:text-sky-400" />
              <span>Category Mix</span>
            </button>
            <button
              id="trend-view-area-btn"
              onClick={() => setViewMode('area')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition cursor-pointer ${
                viewMode === 'area'
                  ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-2xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
              title="Smooth Carbon Trajectory & Cap"
            >
              <TrendingUp className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              <span>Trajectory</span>
            </button>
            <button
              id="trend-view-quarterly-btn"
              onClick={() => setViewMode('quarterly')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition cursor-pointer ${
                viewMode === 'quarterly'
                  ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-2xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
              title="Seasonal Quarterly Aggregates"
            >
              <Calendar className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
              <span>Quarterly</span>
            </button>
          </div>
        </div>
      </div>

      {/* Key Metric Stat Cards Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {/* Metric 1: Year Total */}
        <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-900/50 border border-slate-200/80 dark:border-slate-800">
          <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400 block">
            Annual Cumulative CO₂
          </span>
          <div className="flex items-baseline gap-1 mt-0.5">
            <span className="font-display font-bold text-xl text-slate-900 dark:text-white">
              {totalYearKg.toFixed(1)}
            </span>
            <span className="text-[11px] text-slate-500 dark:text-slate-400">kg</span>
          </div>
          <span className="text-[10px] text-slate-400 block mt-1">
            Across {annualTrends.activeMonthsCount} active {annualTrends.activeMonthsCount === 1 ? 'month' : 'months'}
          </span>
        </div>

        {/* Metric 2: Monthly Average */}
        <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-900/50 border border-slate-200/80 dark:border-slate-800">
          <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400 block">
            Monthly Average
          </span>
          <div className="flex items-baseline gap-1 mt-0.5">
            <span className="font-display font-bold text-xl text-slate-900 dark:text-white">
              {monthlyAverageKg.toFixed(1)}
            </span>
            <span className="text-[11px] text-slate-500 dark:text-slate-400">kg/mo</span>
          </div>
          <span
            className={`text-[10px] block mt-1 font-medium ${
              monthlyAverageKg <= averageMonthlyBudget
                ? 'text-emerald-600 dark:text-emerald-400'
                : 'text-amber-600 dark:text-amber-400'
            }`}
          >
            {monthlyAverageKg <= averageMonthlyBudget
              ? `✓ ${(averageMonthlyBudget - monthlyAverageKg).toFixed(1)} kg under cap`
              : `⚠ ${(monthlyAverageKg - averageMonthlyBudget).toFixed(1)} kg over cap`}
          </span>
        </div>

        {/* Metric 3: Peak Month */}
        <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-900/50 border border-slate-200/80 dark:border-slate-800">
          <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400 block">
            Peak Emission Month
          </span>
          <div className="flex items-baseline gap-1 mt-0.5">
            <span className="font-display font-bold text-xl text-slate-900 dark:text-white">
              {peakMonth ? peakMonth.monthShort : '—'}
            </span>
            {peakMonth && (
              <span className="text-xs font-semibold text-rose-600 dark:text-rose-400">
                {peakMonth.totalKg.toFixed(1)} kg
              </span>
            )}
          </div>
          <span className="text-[10px] text-slate-400 block mt-1">
            {peakMonth
              ? `${peakMonth.travelKg > peakMonth.energyKg ? 'Travel' : 'Energy'} was largest driver`
              : 'No activities logged yet'}
          </span>
        </div>

        {/* Metric 4: Lowest Month */}
        <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-900/50 border border-slate-200/80 dark:border-slate-800">
          <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400 block">
            Most Sustainable Month
          </span>
          <div className="flex items-baseline gap-1 mt-0.5">
            <span className="font-display font-bold text-xl text-slate-900 dark:text-white">
              {lowestActiveMonth ? lowestActiveMonth.monthShort : '—'}
            </span>
            {lowestActiveMonth && (
              <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400">
                {lowestActiveMonth.totalKg.toFixed(1)} kg
              </span>
            )}
          </div>
          <span className="text-[10px] text-slate-400 block mt-1">
            {lowestActiveMonth
              ? `${((1 - lowestActiveMonth.totalKg / Math.max(1, averageMonthlyBudget)) * 100).toFixed(0)}% below budget`
              : 'Awaiting more entries'}
          </span>
        </div>
      </div>

      {/* Primary Chart Area */}
      <div className="space-y-3">
        {/* Legend & Hint */}
        <div className="flex flex-wrap items-center justify-between gap-3 text-xs text-slate-600 dark:text-slate-300 px-1">
          <div className="flex items-center gap-4 flex-wrap">
            {viewMode === 'stacked' || viewMode === 'quarterly' ? (
              <>
                <span className="flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded-xs bg-sky-500"></span>
                  <span className="font-medium">Travel</span>
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded-xs bg-amber-500"></span>
                  <span className="font-medium">Energy</span>
                </span>
                <span className="flex items-center gap-1.5">
                  <span className="w-3 h-3 rounded-xs bg-emerald-500"></span>
                  <span className="font-medium">Food</span>
                </span>
              </>
            ) : (
              <span className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-xs bg-emerald-500"></span>
                <span className="font-medium">Total Monthly Footprint</span>
              </span>
            )}

            <span className="flex items-center gap-1.5">
              <span className="w-4 h-0.5 border-t-2 border-dashed border-emerald-500"></span>
              <span className="text-emerald-600 dark:text-emerald-400 font-medium">
                Monthly Target Cap (~{averageMonthlyBudget} kg)
              </span>
            </span>
          </div>

          <span className="text-[11px] text-slate-400 hidden sm:inline">
            Click any month to inspect details
          </span>
        </div>

        {/* View Mode 1: Stacked Category Bars */}
        {viewMode === 'stacked' && (
          <div className="relative pt-6 pb-2">
            {/* Target Budget Line */}
            <div
              className="absolute left-0 right-0 border-b border-dashed border-emerald-500/80 z-10 pointer-events-none"
              style={{
                bottom: `${Math.min(94, Math.max(12, (averageMonthlyBudget / maxMonthValue) * 100))}%`,
              }}
            >
              <span className="absolute right-2 -top-4 text-[10px] font-semibold text-emerald-700 dark:text-emerald-300 bg-white/95 dark:bg-slate-800/95 px-1.5 py-0.5 rounded border border-emerald-200 dark:border-emerald-800/60 shadow-2xs">
                Cap: {averageMonthlyBudget} kg
              </span>
            </div>

            {/* 12 Months Column Grid */}
            <div className="h-64 sm:h-72 flex items-end justify-between gap-1.5 sm:gap-2.5 pt-6 pb-2 border-b border-slate-100 dark:border-slate-700/80 relative">
              {months.map((m) => {
                const totalPercent =
                  maxMonthValue > 0 ? Math.min(100, (m.totalKg / maxMonthValue) * 100) : 0;
                const isSelected = selectedMonthIndex === m.monthIndex;
                const isHovered = hoveredMonthIndex === m.monthIndex;

                const travelFraction = m.totalKg > 0 ? (m.travelKg / m.totalKg) * 100 : 0;
                const energyFraction = m.totalKg > 0 ? (m.energyKg / m.totalKg) * 100 : 0;
                const foodFraction = m.totalKg > 0 ? (m.foodKg / m.totalKg) * 100 : 0;

                return (
                  <div
                    key={m.monthShort}
                    id={`monthly-bar-${m.monthShort.toLowerCase()}`}
                    onClick={() => setSelectedMonthIndex(selectedMonthIndex === m.monthIndex ? null : m.monthIndex)}
                    onMouseEnter={() => setHoveredMonthIndex(m.monthIndex)}
                    onMouseLeave={() => setHoveredMonthIndex(null)}
                    className="flex-1 flex flex-col items-center h-full justify-end group cursor-pointer relative z-20"
                  >
                    {/* Floating Tooltip */}
                    <div
                      className={`transition-all duration-200 absolute -top-14 bg-slate-900 text-white dark:bg-white dark:text-slate-900 text-[10px] font-medium px-2 py-1.5 rounded-lg shadow-xl pointer-events-none whitespace-nowrap z-30 ${
                        isHovered || isSelected ? 'opacity-100 scale-100' : 'opacity-0 scale-95 pointer-events-none'
                      }`}
                    >
                      <div className="font-bold">{m.monthFull} {m.year}</div>
                      <div className="text-emerald-400 dark:text-emerald-600 font-semibold">
                        {m.totalKg.toFixed(1)} kg CO₂
                      </div>
                    </div>

                    {/* Bar Stack */}
                    <div className="w-full max-w-[44px] h-full flex items-end justify-center">
                      <div
                        className={`w-full rounded-t-lg transition-all duration-300 flex flex-col-reverse overflow-hidden ${
                          isSelected
                            ? 'ring-2 ring-sky-500 dark:ring-sky-400 shadow-md'
                            : m.isCurrentMonth
                            ? 'ring-1 ring-emerald-400'
                            : 'hover:brightness-105'
                        } ${
                          m.totalKg === 0
                            ? 'bg-slate-100 dark:bg-slate-700/40'
                            : ''
                        }`}
                        style={{
                          height: `${Math.max(6, Math.round(totalPercent))}%`,
                        }}
                      >
                        {/* Food segment (bottom of stack) */}
                        {m.foodKg > 0 && (
                          <div
                            className="w-full bg-emerald-500 dark:bg-emerald-400"
                            style={{ height: `${foodFraction}%` }}
                            title={`Food: ${m.foodKg.toFixed(1)} kg`}
                          />
                        )}
                        {/* Energy segment (middle of stack) */}
                        {m.energyKg > 0 && (
                          <div
                            className="w-full bg-amber-500 dark:bg-amber-400"
                            style={{ height: `${energyFraction}%` }}
                            title={`Energy: ${m.energyKg.toFixed(1)} kg`}
                          />
                        )}
                        {/* Travel segment (top of stack) */}
                        {m.travelKg > 0 && (
                          <div
                            className="w-full bg-sky-500 dark:bg-sky-400"
                            style={{ height: `${travelFraction}%` }}
                            title={`Travel: ${m.travelKg.toFixed(1)} kg`}
                          />
                        )}
                      </div>
                    </div>

                    {/* Month Label */}
                    <div className="mt-2 text-center w-full">
                      <span
                        className={`block text-[11px] font-semibold truncate ${
                          m.isCurrentMonth
                            ? 'text-emerald-600 dark:text-emerald-400'
                            : isSelected
                            ? 'text-sky-600 dark:text-sky-400'
                            : 'text-slate-600 dark:text-slate-400'
                        }`}
                      >
                        {m.monthShort}
                      </span>
                      <span className="block text-[9px] text-slate-400 truncate">
                        {m.totalKg > 0 ? `${m.totalKg.toFixed(0)}kg` : '—'}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* View Mode 2: Continuous Trajectory Area Curve */}
        {viewMode === 'area' && (
          <div className="relative pt-6 pb-2">
            <div className="w-full h-64 sm:h-72 overflow-hidden">
              <svg
                viewBox={`0 0 ${chartSvgWidth} ${chartSvgHeight}`}
                className="w-full h-full"
                preserveAspectRatio="none"
              >
                <defs>
                  <linearGradient id="monthlyAreaGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#0ea5e9" stopOpacity="0.4" />
                    <stop offset="60%" stopColor="#10b981" stopOpacity="0.15" />
                    <stop offset="100%" stopColor="#10b981" stopOpacity="0.0" />
                  </linearGradient>
                </defs>

                {/* Grid guidelines */}
                {[0.25, 0.5, 0.75, 1.0].map((frac) => {
                  const y = chartSvgHeight - paddingY - frac * plotHeight;
                  return (
                    <line
                      key={frac}
                      x1={paddingX}
                      y1={y}
                      x2={chartSvgWidth - paddingX}
                      y2={y}
                      stroke="#94a3b8"
                      strokeOpacity="0.2"
                      strokeDasharray="4 4"
                    />
                  );
                })}

                {/* Target Budget Line */}
                <line
                  x1={paddingX}
                  y1={budgetLineY}
                  x2={chartSvgWidth - paddingX}
                  y2={budgetLineY}
                  stroke="#10b981"
                  strokeWidth="1.5"
                  strokeDasharray="5 4"
                />

                {/* Filled Area */}
                <path d={areaPath} fill="url(#monthlyAreaGrad)" />

                {/* Line Path */}
                <path
                  d={linePath}
                  fill="none"
                  stroke="#0284c7"
                  strokeWidth="2.5"
                  strokeLinecap="round"
                />

                {/* Data Points */}
                {points.map((pt, idx) => {
                  const isSelected = selectedMonthIndex === idx;
                  return (
                    <g
                      key={idx}
                      className="cursor-pointer"
                      onClick={() => setSelectedMonthIndex(selectedMonthIndex === idx ? null : idx)}
                    >
                      <circle
                        cx={pt.x}
                        cy={pt.y}
                        r={isSelected ? 6 : 4}
                        className={`transition-all ${
                          isSelected
                            ? 'fill-sky-500 stroke-white dark:stroke-slate-900 stroke-2'
                            : pt.month.isCurrentMonth
                            ? 'fill-emerald-500 stroke-white stroke-1.5'
                            : 'fill-slate-600 dark:fill-slate-300 hover:fill-sky-400'
                        }`}
                      />
                    </g>
                  );
                })}
              </svg>
            </div>

            {/* X Axis Labels under SVG */}
            <div className="flex justify-between px-3 text-[11px] font-semibold text-slate-500 dark:text-slate-400 border-t border-slate-100 dark:border-slate-700/80 pt-2">
              {months.map((m) => (
                <button
                  key={m.monthShort}
                  id={`area-month-btn-${m.monthShort.toLowerCase()}`}
                  type="button"
                  onClick={() => setSelectedMonthIndex(selectedMonthIndex === m.monthIndex ? null : m.monthIndex)}
                  className={`cursor-pointer transition ${
                    selectedMonthIndex === m.monthIndex
                      ? 'text-sky-600 dark:text-sky-400 font-bold'
                      : m.isCurrentMonth
                      ? 'text-emerald-600 dark:text-emerald-400 font-bold'
                      : 'hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  {m.monthShort}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* View Mode 3: Quarterly Seasonal Aggregates */}
        {viewMode === 'quarterly' && (
          <div className="relative pt-6 pb-2">
            {/* Target Budget Line for Quarter (3 months) */}
            <div
              className="absolute left-0 right-0 border-b border-dashed border-emerald-500/80 z-10 pointer-events-none"
              style={{
                bottom: `${Math.min(94, Math.max(12, ((averageMonthlyBudget * 3) / maxQuarterlyValue) * 100))}%`,
              }}
            >
              <span className="absolute right-2 -top-4 text-[10px] font-semibold text-emerald-700 dark:text-emerald-300 bg-white/95 dark:bg-slate-800/95 px-1.5 py-0.5 rounded border border-emerald-200 dark:border-emerald-800/60 shadow-2xs">
                Quarter Cap: {(averageMonthlyBudget * 3).toFixed(1)} kg
              </span>
            </div>

            <div className="h-64 sm:h-72 flex items-end justify-around gap-4 sm:gap-8 pt-6 pb-2 border-b border-slate-100 dark:border-slate-700/80 relative">
              {quarterly.map((q) => {
                const totalPercent =
                  maxQuarterlyValue > 0 ? Math.min(100, (q.totalKg / maxQuarterlyValue) * 100) : 0;
                const travelFraction = q.totalKg > 0 ? (q.travelKg / q.totalKg) * 100 : 0;
                const energyFraction = q.totalKg > 0 ? (q.energyKg / q.totalKg) * 100 : 0;
                const foodFraction = q.totalKg > 0 ? (q.foodKg / q.totalKg) * 100 : 0;

                return (
                  <div
                    key={q.quarter}
                    id={`quarter-bar-${q.quarter.toLowerCase()}`}
                    onClick={() => setSelectedQuarter(selectedQuarter === q.quarter ? null : q.quarter)}
                    className={`flex-1 flex flex-col items-center h-full justify-end max-w-[120px] group relative z-20 cursor-pointer p-1 rounded-xl transition ${
                      selectedQuarter === q.quarter
                        ? 'bg-amber-500/10 ring-2 ring-amber-500/50'
                        : 'hover:bg-slate-100/50 dark:hover:bg-slate-800/50'
                    }`}
                  >
                    {/* Tooltip */}
                    <div className="opacity-0 group-hover:opacity-100 transition-opacity absolute -top-16 bg-slate-900 text-white text-[10px] font-medium p-2 rounded-lg shadow-xl pointer-events-none whitespace-nowrap z-30">
                      <div className="font-bold">{q.label}</div>
                      <div>Total: {q.totalKg.toFixed(1)} kg CO₂</div>
                      <div className="text-sky-300">Travel: {q.travelKg.toFixed(1)} kg</div>
                      <div className="text-amber-300">Energy: {q.energyKg.toFixed(1)} kg</div>
                      <div className="text-emerald-300">Food: {q.foodKg.toFixed(1)} kg</div>
                    </div>

                    {/* Bar Stack */}
                    <div className="w-full h-full flex items-end justify-center">
                      <div
                        className="w-full max-w-[64px] rounded-t-xl bg-slate-100 dark:bg-slate-700/50 flex flex-col-reverse overflow-hidden shadow-xs"
                        style={{ height: `${Math.max(8, Math.round(totalPercent))}%` }}
                      >
                        {q.foodKg > 0 && (
                          <div
                            className="w-full bg-emerald-500 dark:bg-emerald-400"
                            style={{ height: `${foodFraction}%` }}
                          />
                        )}
                        {q.energyKg > 0 && (
                          <div
                            className="w-full bg-amber-500 dark:bg-amber-400"
                            style={{ height: `${energyFraction}%` }}
                          />
                        )}
                        {q.travelKg > 0 && (
                          <div
                            className="w-full bg-sky-500 dark:bg-sky-400"
                            style={{ height: `${travelFraction}%` }}
                          />
                        )}
                      </div>
                    </div>

                    {/* Label */}
                    <div className="mt-3 text-center">
                      <span className="block text-xs font-bold text-slate-800 dark:text-slate-200">
                        {q.quarter}
                      </span>
                      <span className="block text-[10px] text-slate-400">
                        {q.totalKg.toFixed(1)} kg CO₂
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* Selected Month Detailed Drilldown Card */}
      {activeMonthData && (
        <div
          id="month-drilldown-card"
          className="p-4 rounded-xl bg-slate-50/90 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 transition-all"
        >
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200/60 dark:border-slate-800">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-lg bg-sky-100 dark:bg-sky-950/80 text-sky-700 dark:text-sky-300 flex items-center justify-center font-bold text-xs uppercase">
                {activeMonthData.monthShort}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                    {activeMonthData.monthFull} {activeMonthData.year} Drilldown
                  </h4>
                  {activeMonthData.isCurrentMonth && (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                      Current Month
                    </span>
                  )}
                  {activeMonthData.isFutureMonth && (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-300">
                      Upcoming
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {activeMonthData.activityCount} logged {activeMonthData.activityCount === 1 ? 'activity' : 'activities'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="text-right">
                <span className="text-[11px] text-slate-400 block">Monthly Total</span>
                <span className="font-display font-bold text-lg text-slate-900 dark:text-white">
                  {activeMonthData.totalKg.toFixed(2)} <span className="text-xs font-normal">kg CO₂</span>
                </span>
              </div>

              {activeMonthData.changeFromPrevMonthKg !== null && (
                <div
                  className={`px-2.5 py-1 rounded-lg text-xs font-semibold flex items-center gap-1 ${
                    activeMonthData.changeFromPrevMonthKg <= 0
                      ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800'
                      : 'bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300 border border-rose-200 dark:border-rose-800'
                  }`}
                  title="Change compared to previous month"
                >
                  {activeMonthData.changeFromPrevMonthKg <= 0 ? (
                    <TrendingDown className="w-3.5 h-3.5" />
                  ) : (
                    <TrendingUp className="w-3.5 h-3.5" />
                  )}
                  <span>
                    {activeMonthData.changeFromPrevMonthKg > 0 ? '+' : ''}
                    {activeMonthData.changeFromPrevMonthKg.toFixed(1)} kg
                    {activeMonthData.changeFromPrevMonthPercent !== null &&
                      ` (${activeMonthData.changeFromPrevMonthPercent > 0 ? '+' : ''}${activeMonthData.changeFromPrevMonthPercent}%)`}
                  </span>
                </div>
              )}

              <button
                id="close-month-drilldown-button"
                type="button"
                onClick={() => setSelectedMonthIndex(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-200/70 dark:hover:bg-slate-700 transition cursor-pointer"
                title="Dismiss month drilldown"
                aria-label="Dismiss month drilldown"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Breakdown progress pills */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-3">
            {/* Travel */}
            <div className="p-2.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200/70 dark:border-slate-700">
              <div className="flex items-center justify-between text-xs text-slate-600 dark:text-slate-300">
                <span className="flex items-center gap-1.5 font-medium">
                  <Car className="w-3.5 h-3.5 text-sky-600 dark:text-sky-400" />
                  <span>Travel</span>
                </span>
                <span className="font-bold text-slate-900 dark:text-white">
                  {activeMonthData.travelKg.toFixed(1)} kg
                </span>
              </div>
              <div className="w-full h-1.5 bg-slate-100 dark:bg-slate-700 rounded-full mt-2 overflow-hidden">
                <div
                  className="h-full bg-sky-500 rounded-full"
                  style={{
                    width: `${
                      activeMonthData.totalKg > 0
                        ? Math.round((activeMonthData.travelKg / activeMonthData.totalKg) * 100)
                        : 0
                    }%`,
                  }}
                />
              </div>
              <span className="text-[10px] text-slate-400 block mt-1">
                {activeMonthData.totalKg > 0
                  ? `${Math.round((activeMonthData.travelKg / activeMonthData.totalKg) * 100)}% of monthly total`
                  : '0%'}
              </span>
            </div>

            {/* Energy */}
            <div className="p-2.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200/70 dark:border-slate-700">
              <div className="flex items-center justify-between text-xs text-slate-600 dark:text-slate-300">
                <span className="flex items-center gap-1.5 font-medium">
                  <Zap className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                  <span>Energy</span>
                </span>
                <span className="font-bold text-slate-900 dark:text-white">
                  {activeMonthData.energyKg.toFixed(1)} kg
                </span>
              </div>
              <div className="w-full h-1.5 bg-slate-100 dark:bg-slate-700 rounded-full mt-2 overflow-hidden">
                <div
                  className="h-full bg-amber-500 rounded-full"
                  style={{
                    width: `${
                      activeMonthData.totalKg > 0
                        ? Math.round((activeMonthData.energyKg / activeMonthData.totalKg) * 100)
                        : 0
                    }%`,
                  }}
                />
              </div>
              <span className="text-[10px] text-slate-400 block mt-1">
                {activeMonthData.totalKg > 0
                  ? `${Math.round((activeMonthData.energyKg / activeMonthData.totalKg) * 100)}% of monthly total`
                  : '0%'}
              </span>
            </div>

            {/* Food */}
            <div className="p-2.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200/70 dark:border-slate-700">
              <div className="flex items-center justify-between text-xs text-slate-600 dark:text-slate-300">
                <span className="flex items-center gap-1.5 font-medium">
                  <Salad className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                  <span>Food</span>
                </span>
                <span className="font-bold text-slate-900 dark:text-white">
                  {activeMonthData.foodKg.toFixed(1)} kg
                </span>
              </div>
              <div className="w-full h-1.5 bg-slate-100 dark:bg-slate-700 rounded-full mt-2 overflow-hidden">
                <div
                  className="h-full bg-emerald-500 rounded-full"
                  style={{
                    width: `${
                      activeMonthData.totalKg > 0
                        ? Math.round((activeMonthData.foodKg / activeMonthData.totalKg) * 100)
                        : 0
                    }%`,
                  }}
                />
              </div>
              <span className="text-[10px] text-slate-400 block mt-1">
                {activeMonthData.totalKg > 0
                  ? `${Math.round((activeMonthData.foodKg / activeMonthData.totalKg) * 100)}% of monthly total`
                  : '0%'}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Selected Quarter Detailed Drilldown Card */}
      {selectedQuarterData && (
        <div
          id="quarter-drilldown-card"
          className="p-4 rounded-xl bg-slate-50/90 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 transition-all"
        >
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200/60 dark:border-slate-800">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-lg bg-amber-100 dark:bg-amber-950/80 text-amber-700 dark:text-amber-300 flex items-center justify-center font-bold text-xs">
                {selectedQuarterData.quarter}
              </div>
              <div>
                <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                  {selectedQuarterData.label} Seasonal Breakdown
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {selectedQuarterData.months.map((m) => m.monthShort).join(' • ')} • {selectedQuarterData.months.reduce((acc, m) => acc + m.activityCount, 0)} logged activities
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="text-right">
                <span className="text-[11px] text-slate-400 block">Quarter Total</span>
                <span className="font-display font-bold text-lg text-slate-900 dark:text-white">
                  {selectedQuarterData.totalKg.toFixed(2)} <span className="text-xs font-normal">kg CO₂</span>
                </span>
              </div>
              <button
                id="close-quarter-drilldown-button"
                type="button"
                onClick={() => setSelectedQuarter(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-200/70 dark:hover:bg-slate-700 transition cursor-pointer"
                title="Dismiss quarter drilldown"
                aria-label="Dismiss quarter drilldown"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-3">
            <div className="p-2.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200/70 dark:border-slate-700">
              <div className="flex items-center justify-between text-xs text-slate-600 dark:text-slate-300">
                <span className="flex items-center gap-1.5 font-medium">
                  <Car className="w-3.5 h-3.5 text-sky-600 dark:text-sky-400" />
                  <span>Travel</span>
                </span>
                <span className="font-bold text-slate-900 dark:text-white">
                  {selectedQuarterData.travelKg.toFixed(1)} kg
                </span>
              </div>
            </div>
            <div className="p-2.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200/70 dark:border-slate-700">
              <div className="flex items-center justify-between text-xs text-slate-600 dark:text-slate-300">
                <span className="flex items-center gap-1.5 font-medium">
                  <Zap className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
                  <span>Energy</span>
                </span>
                <span className="font-bold text-slate-900 dark:text-white">
                  {selectedQuarterData.energyKg.toFixed(1)} kg
                </span>
              </div>
            </div>
            <div className="p-2.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200/70 dark:border-slate-700">
              <div className="flex items-center justify-between text-xs text-slate-600 dark:text-slate-300">
                <span className="flex items-center gap-1.5 font-medium">
                  <Salad className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                  <span>Food</span>
                </span>
                <span className="font-bold text-slate-900 dark:text-white">
                  {selectedQuarterData.foodKg.toFixed(1)} kg
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Seasonal Intelligence Footer Callout */}
      <div className="p-4 rounded-xl bg-gradient-to-r from-sky-50/70 via-emerald-50/40 to-white dark:from-sky-950/40 dark:via-emerald-950/20 dark:to-slate-800/40 border border-sky-200/70 dark:border-sky-900/60 flex items-start gap-3">
        <div className="p-2 rounded-lg bg-white dark:bg-slate-800 text-sky-600 dark:text-sky-400 border border-sky-100 dark:border-slate-700 shrink-0">
          <Sparkles className="w-4 h-4" />
        </div>
        <div>
          <h5 className="font-bold text-xs text-slate-900 dark:text-white flex items-center gap-1.5">
            <span>Seasonal Usage Dynamics & Trajectory</span>
          </h5>
          <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 leading-relaxed">
            {seasonalityInsight}
          </p>
          <div className="flex items-center gap-4 mt-2 text-[11px] text-slate-500 dark:text-slate-400">
            <span className="flex items-center gap-1">
              <Target className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              Annual Target Budget: {annualTrends.annualBudgetKg} kg CO₂
            </span>
            <span className="flex items-center gap-1">
              <Info className="w-3.5 h-3.5 text-sky-600 dark:text-sky-400" />
              Target Cap dynamically scales with calendar days per month
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
