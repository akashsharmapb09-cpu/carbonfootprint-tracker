import React, { useState, useRef, useEffect } from 'react';
import {
  Leaf,
  Plus,
  Sun,
  Moon,
  Monitor,
  Check,
  ChevronDown,
  Download,
  RotateCcw,
  Target,
  FileSpreadsheet,
  FileJson,
  X,
  Flame,
  Database,
  RefreshCw,
  AlertTriangle,
  Trash2,
} from 'lucide-react';
import { CarbonActivity, ThemePreference } from '../types';
import { downloadActivitiesCSV } from '../utils/csvExport';

interface NavbarProps {
  onOpenLogModal: () => void;
  onOpenTargetModal: () => void;
  onResetDemo: () => void;
  onClearAll: () => void;
  activities: CarbonActivity[];
  weeklyTarget: number;
  currentWeekTotal: number;
  currentStreak?: number;
  isDark: boolean;
  themePreference?: ThemePreference;
  onToggleTheme: () => void;
  onSelectTheme?: (pref: ThemePreference) => void;
  lastSaved?: number;
  isSyncing?: boolean;
  onManualSync?: () => void;
}

function formatLastSavedRelative(timestamp?: number, now?: number): string {
  if (!timestamp) return 'Saved';
  const currentNow = now || Date.now();
  const diffSec = Math.max(0, Math.floor((currentNow - timestamp) / 1000));
  if (diffSec < 6) return 'Saved just now';
  if (diffSec < 60) return `Saved ${diffSec}s ago`;
  const diffMin = Math.floor(diffSec / 60);
  if (diffMin < 60) return `Saved ${diffMin}m ago`;
  const diffHours = Math.floor(diffMin / 60);
  if (diffHours < 24) return `Saved ${diffHours}h ago`;
  return `Saved ${new Date(timestamp).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}`;
}

function formatLastSavedExact(timestamp?: number): string {
  if (!timestamp) return 'Recently';
  return new Date(timestamp).toLocaleTimeString(undefined, {
    hour: 'numeric',
    minute: '2-digit',
    second: '2-digit',
  });
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenLogModal,
  onOpenTargetModal,
  onResetDemo,
  onClearAll,
  activities,
  weeklyTarget,
  currentWeekTotal,
  currentStreak = 0,
  isDark,
  themePreference = 'system',
  onToggleTheme,
  onSelectTheme,
  lastSaved,
  isSyncing = false,
  onManualSync,
}) => {
  const [showMenu, setShowMenu] = useState(false);
  const [showThemeMenu, setShowThemeMenu] = useState(false);
  const [showStatusPopover, setShowStatusPopover] = useState(false);
  const [showExportModal, setShowExportModal] = useState(false);
  const [showClearConfirmModal, setShowClearConfirmModal] = useState(false);
  const [showResetConfirmModal, setShowResetConfirmModal] = useState(false);
  const [actionFeedback, setActionFeedback] = useState<string | null>(null);
  const [justSavedNotice, setJustSavedNotice] = useState(false);
  const [now, setNow] = useState<number>(Date.now());

  const themeMenuRef = useRef<HTMLDivElement>(null);
  const dataMenuRef = useRef<HTMLDivElement>(null);
  const statusMenuRef = useRef<HTMLDivElement>(null);
  const prevSyncingRef = useRef(isSyncing);

  const triggerFeedback = (message: string) => {
    setActionFeedback(message);
    setTimeout(() => {
      setActionFeedback(null);
    }, 3200);
  };

  // Trigger flash notice when a sync operation finishes
  useEffect(() => {
    if (prevSyncingRef.current && !isSyncing) {
      setJustSavedNotice(true);
      const timer = setTimeout(() => setJustSavedNotice(false), 2400);
      return () => clearTimeout(timer);
    }
    prevSyncingRef.current = isSyncing;
  }, [isSyncing]);

  // Periodic timer to keep relative time accurate
  useEffect(() => {
    const timer = setInterval(() => {
      setNow(Date.now());
    }, 10000);
    return () => clearInterval(timer);
  }, []);

  // Close menus when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (themeMenuRef.current && !themeMenuRef.current.contains(event.target as Node)) {
        setShowThemeMenu(false);
      }
      if (dataMenuRef.current && !dataMenuRef.current.contains(event.target as Node)) {
        setShowMenu(false);
      }
      if (statusMenuRef.current && !statusMenuRef.current.contains(event.target as Node)) {
        setShowStatusPopover(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const percentUsed = Math.min(999, Math.round((currentWeekTotal / Math.max(1, weeklyTarget)) * 100));

  const exportCSV = () => {
    if (activities.length === 0) return;
    const success = downloadActivitiesCSV(activities, 'ecotrack-emissions');
    if (success) {
      triggerFeedback(`Exported ${activities.length} entries to CSV`);
    }
    setShowExportModal(false);
  };

  const exportJSON = () => {
    if (activities.length === 0) return;
    try {
      const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(activities, null, 2));
      const link = document.createElement('a');
      link.setAttribute('href', dataStr);
      link.setAttribute('download', `ecotrack-backup-${new Date().toISOString().split('T')[0]}.json`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      triggerFeedback(`Saved backup of ${activities.length} entries to JSON`);
    } catch (e) {
      console.error('Failed to export JSON', e);
    }
    setShowExportModal(false);
  };

  const handleConfirmReset = () => {
    setShowResetConfirmModal(false);
    onResetDemo();
    triggerFeedback('Demo dataset reloaded successfully');
  };

  const handleConfirmClearAll = () => {
    setShowClearConfirmModal(false);
    onClearAll();
    triggerFeedback('All logged activities cleared');
  };

  return (
    <>
      <header className="sticky top-0 z-30 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 transition-colors">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 sm:h-18">
            {/* Logo & App Title */}
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-600 dark:bg-emerald-500 flex items-center justify-center text-white shadow-sm shadow-emerald-500/20">
                <Leaf className="w-5 h-5 stroke-[2.5]" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-display font-bold text-xl tracking-tight text-slate-900 dark:text-white">
                    EcoTrack
                  </span>
                  <span className="hidden sm:inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-200/60 dark:border-emerald-800/40">
                    Carbon Tracker
                  </span>
                </div>
                <p className="hidden sm:block text-xs text-slate-500 dark:text-slate-400">
                  Daily Emissions & Target Monitor
                </p>
              </div>
            </div>

            {/* Middle Quick Target Status (Tablet+) */}
            <div className="hidden md:flex items-center gap-2.5">
              <button
                id="target-badge-button"
                onClick={onOpenTargetModal}
                className="flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-100 dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-200/80 dark:border-slate-700 transition cursor-pointer"
                title="Click to adjust weekly target"
              >
                <Target className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                <span>
                  Budget: <strong>{weeklyTarget} kg</strong>
                </span>
                <span
                  className={`px-1.5 py-0.5 rounded font-semibold text-[11px] ${
                    percentUsed >= 100
                      ? 'bg-rose-100 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300'
                      : percentUsed >= 80
                      ? 'bg-amber-100 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300'
                      : 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300'
                  }`}
                >
                  {percentUsed}%
                </span>
              </button>

              {currentStreak > 0 && (
                <a
                  id="navbar-streak-link"
                  href="#weekly-goal-streak-card"
                  onClick={(e) => {
                    e.preventDefault();
                    document.getElementById('weekly-goal-streak-card')?.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-bold bg-amber-50 dark:bg-amber-950/60 text-amber-900 dark:text-amber-200 border border-amber-200 dark:border-amber-800 transition hover:bg-amber-100 dark:hover:bg-amber-900/60 cursor-pointer shadow-2xs"
                  title="Weekly Goal Streak Active! Click to view rewards"
                >
                  <Flame className="w-3.5 h-3.5 fill-amber-500 text-amber-500" />
                  <span>{currentStreak}w Streak</span>
                </a>
              )}
            </div>

            {/* Action Buttons */}
            <div className="flex items-center gap-2 sm:gap-3">
              {/* LocalStorage Status Indicator & Manual Sync/Save */}
              <div className="relative" ref={statusMenuRef}>
                <div
                  id="storage-sync-pill"
                  className="flex items-center rounded-lg border border-slate-200/90 dark:border-slate-700 bg-white/70 dark:bg-slate-800/80 p-0.5 shadow-2xs text-xs"
                >
                  {/* Status Indicator Button / Popover Trigger */}
                  <button
                    id="storage-status-indicator"
                    onClick={() => setShowStatusPopover(!showStatusPopover)}
                    aria-label="Storage status details"
                    title={`Storage: ${isSyncing ? 'Saving...' : justSavedNotice ? 'Saved!' : formatLastSavedRelative(lastSaved, now)} (${formatLastSavedExact(lastSaved)}). Click for details.`}
                    className="flex items-center gap-1.5 px-2 py-1.5 rounded-md text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 transition cursor-pointer"
                  >
                    <span className="relative flex h-2 w-2 shrink-0">
                      {isSyncing || justSavedNotice ? (
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                      ) : null}
                      <span
                        className={`relative inline-flex rounded-full h-2 w-2 transition-colors duration-300 ${
                          isSyncing ? 'bg-amber-500' : 'bg-emerald-500'
                        }`}
                      ></span>
                    </span>

                    <Database className="w-3.5 h-3.5 text-slate-400 dark:text-slate-400 hidden sm:inline" />

                    <span className="text-[11px] font-medium hidden md:inline select-none whitespace-nowrap">
                      {isSyncing ? (
                        <span className="text-amber-600 dark:text-amber-400 font-semibold">Saving...</span>
                      ) : justSavedNotice ? (
                        <span className="text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-1">
                          <Check className="w-3 h-3 stroke-[3]" />
                          Saved!
                        </span>
                      ) : (
                        formatLastSavedRelative(lastSaved, now)
                      )}
                    </span>
                  </button>

                  {/* Manual Sync/Save Button */}
                  <button
                    id="manual-sync-save-button"
                    onClick={onManualSync}
                    disabled={isSyncing}
                    aria-label="Manually save and sync data to local storage"
                    title="Manually save and synchronize data to local storage"
                    className="flex items-center gap-1 px-2 py-1.5 rounded-md font-semibold text-[11px] bg-slate-100 hover:bg-emerald-50 dark:bg-slate-700/80 dark:hover:bg-emerald-950/40 text-slate-700 dark:text-slate-200 hover:text-emerald-700 dark:hover:text-emerald-300 border border-slate-200/80 dark:border-slate-600 transition cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed shadow-2xs"
                  >
                    <RefreshCw
                      className={`w-3 h-3 text-emerald-600 dark:text-emerald-400 transition-transform ${
                        isSyncing ? 'animate-spin' : ''
                      }`}
                    />
                    <span className="hidden sm:inline">
                      {isSyncing ? 'Saving' : 'Save'}
                    </span>
                  </button>
                </div>

                {/* Detailed Storage Status Popover */}
                {showStatusPopover && (
                  <div
                    id="storage-status-popover"
                    className="absolute right-0 mt-1.5 w-72 bg-white dark:bg-slate-800 rounded-xl shadow-xl border border-slate-200 dark:border-slate-700 p-3.5 z-50 animate-in fade-in zoom-in-95 duration-150 text-xs"
                  >
                    <div className="flex items-center justify-between pb-2 mb-2.5 border-b border-slate-100 dark:border-slate-700">
                      <div className="flex items-center gap-1.5 font-bold text-slate-800 dark:text-slate-100">
                        <Database className="w-4 h-4 text-emerald-500" />
                        <span>Storage & Backup Status</span>
                      </div>
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 dark:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300">
                        <Check className="w-3 h-3 stroke-[2.5]" />
                        Active
                      </span>
                    </div>

                    <div className="space-y-2 text-slate-600 dark:text-slate-300 text-[11px]">
                      <div className="flex items-center justify-between">
                        <span className="text-slate-400 dark:text-slate-500">Storage engine:</span>
                        <span className="font-semibold text-slate-800 dark:text-slate-200">
                          Browser LocalStorage
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-slate-400 dark:text-slate-500">Last saved:</span>
                        <span className="font-semibold text-slate-800 dark:text-slate-200">
                          {formatLastSavedExact(lastSaved)}
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-slate-400 dark:text-slate-500">Relative:</span>
                        <span className="font-medium text-slate-700 dark:text-slate-300">
                          {formatLastSavedRelative(lastSaved, now)}
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-slate-400 dark:text-slate-500">Saved records:</span>
                        <span className="font-semibold text-slate-800 dark:text-slate-200">
                          {activities.length} activities
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-slate-400 dark:text-slate-500">Weekly target:</span>
                        <span className="font-semibold text-slate-800 dark:text-slate-200">
                          {weeklyTarget} kg CO₂/week
                        </span>
                      </div>
                    </div>

                    <div className="mt-3 pt-2.5 border-t border-slate-100 dark:border-slate-700 flex items-center justify-between gap-2">
                      <span className="text-[10px] text-slate-400">
                        Persisted across browser sessions
                      </span>
                      <button
                        id="popover-sync-button"
                        onClick={() => {
                          onManualSync?.();
                          setShowStatusPopover(false);
                        }}
                        disabled={isSyncing}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs shadow-xs transition cursor-pointer disabled:opacity-50"
                      >
                        <RefreshCw className={`w-3 h-3 ${isSyncing ? 'animate-spin' : ''}`} />
                        <span>Save Now</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* Theme Preference Selector / Toggle */}
              <div className="relative" ref={themeMenuRef}>
                <div className="flex items-center rounded-lg border border-slate-200/90 dark:border-slate-700 bg-white/70 dark:bg-slate-800/80 p-0.5 shadow-2xs">
                  <button
                    id="theme-toggle-button"
                    onClick={onToggleTheme}
                    aria-label={`Toggle theme (currently ${themePreference === 'system' ? 'System (' + (isDark ? 'Dark' : 'Light') + ')' : isDark ? 'Dark' : 'Light'})`}
                    title={`Theme: ${themePreference === 'system' ? 'System (' + (isDark ? 'Dark' : 'Light') + ')' : isDark ? 'Dark' : 'Light'}. Click to toggle.`}
                    className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 text-xs font-semibold transition cursor-pointer"
                  >
                    {isDark ? (
                      <Moon className="w-4 h-4 text-emerald-500 dark:text-emerald-400 fill-emerald-400/20" />
                    ) : (
                      <Sun className="w-4 h-4 text-amber-500 fill-amber-500/20" />
                    )}
                    <span className="hidden sm:inline text-[11px] font-medium capitalize">
                      {themePreference === 'system' ? 'Auto' : isDark ? 'Dark' : 'Light'}
                    </span>
                  </button>
                  <button
                    id="theme-dropdown-toggle"
                    onClick={() => setShowThemeMenu(!showThemeMenu)}
                    aria-label="Select theme preference"
                    title="Theme options (Light, Dark, System)"
                    className="p-1.5 rounded-md text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 transition cursor-pointer"
                  >
                    <ChevronDown className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Theme Options Dropdown */}
                {showThemeMenu && (
                  <div
                    id="theme-dropdown-menu"
                    className="absolute right-0 mt-1.5 w-48 bg-white dark:bg-slate-800 rounded-xl shadow-xl border border-slate-200 dark:border-slate-700 py-1.5 z-50 animate-in fade-in zoom-in-95 duration-150 text-xs"
                  >
                    <div className="px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                      Appearance
                    </div>
                    <button
                      id="theme-select-light"
                      onClick={() => {
                        onSelectTheme?.('light');
                        setShowThemeMenu(false);
                      }}
                      className={`w-full text-left px-3 py-2 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-700/60 transition cursor-pointer ${
                        themePreference === 'light'
                          ? 'text-emerald-600 dark:text-emerald-400 font-semibold bg-emerald-50/70 dark:bg-emerald-950/40'
                          : 'text-slate-700 dark:text-slate-200'
                      }`}
                    >
                      <span className="flex items-center gap-2">
                        <Sun className="w-3.5 h-3.5 text-amber-500" />
                        <span>Light</span>
                      </span>
                      {themePreference === 'light' && <Check className="w-3.5 h-3.5 stroke-[2.5]" />}
                    </button>
                    <button
                      id="theme-select-dark"
                      onClick={() => {
                        onSelectTheme?.('dark');
                        setShowThemeMenu(false);
                      }}
                      className={`w-full text-left px-3 py-2 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-700/60 transition cursor-pointer ${
                        themePreference === 'dark'
                          ? 'text-emerald-600 dark:text-emerald-400 font-semibold bg-emerald-50/70 dark:bg-emerald-950/40'
                          : 'text-slate-700 dark:text-slate-200'
                      }`}
                    >
                      <span className="flex items-center gap-2">
                        <Moon className="w-3.5 h-3.5 text-emerald-500" />
                        <span>Dark</span>
                      </span>
                      {themePreference === 'dark' && <Check className="w-3.5 h-3.5 stroke-[2.5]" />}
                    </button>
                    <button
                      id="theme-select-system"
                      onClick={() => {
                        onSelectTheme?.('system');
                        setShowThemeMenu(false);
                      }}
                      className={`w-full text-left px-3 py-2 flex items-center justify-between hover:bg-slate-50 dark:hover:bg-slate-700/60 transition cursor-pointer ${
                        themePreference === 'system'
                          ? 'text-emerald-600 dark:text-emerald-400 font-semibold bg-emerald-50/70 dark:bg-emerald-950/40'
                          : 'text-slate-700 dark:text-slate-200'
                      }`}
                    >
                      <span className="flex items-center gap-2">
                        <Monitor className="w-3.5 h-3.5 text-sky-500" />
                        <span>System Auto</span>
                      </span>
                      {themePreference === 'system' && <Check className="w-3.5 h-3.5 stroke-[2.5]" />}
                    </button>
                  </div>
                )}
              </div>

              {/* Data Export / Reset Menu */}
              <div className="relative" ref={dataMenuRef}>
                <button
                  id="data-menu-button"
                  onClick={() => setShowMenu(!showMenu)}
                  className="p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer border border-transparent hover:border-slate-200 dark:hover:border-slate-700"
                  aria-label="Data options"
                  title="Data & Export Options"
                >
                  <Download className="w-4 h-4" />
                </button>

                {showMenu && (
                  <div
                    id="data-dropdown-menu"
                    className="absolute right-0 mt-2 w-52 bg-white dark:bg-slate-800 rounded-xl shadow-lg border border-slate-200 dark:border-slate-700 py-1.5 z-50 animate-in fade-in zoom-in-95 duration-150"
                  >
                    <div className="px-3 py-1.5 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                      Data Management
                    </div>
                    <button
                      id="menu-sync-now-button"
                      onClick={() => {
                        setShowMenu(false);
                        onManualSync?.();
                      }}
                      className="w-full text-left px-3 py-2 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 flex items-center justify-between cursor-pointer"
                    >
                      <span className="flex items-center gap-2">
                        <RefreshCw className={`w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 ${isSyncing ? 'animate-spin' : ''}`} />
                        <span>Save & Sync Storage</span>
                      </span>
                      <span className="text-[10px] text-slate-400">
                        {formatLastSavedExact(lastSaved)}
                      </span>
                    </button>
                    <button
                      id="data-export-menu-btn"
                      onClick={() => {
                        setShowMenu(false);
                        setShowExportModal(true);
                      }}
                      className="w-full text-left px-3 py-2 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 flex items-center gap-2 cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5 text-slate-500" />
                      Export Data (CSV / JSON)
                    </button>
                    <button
                      id="data-reload-demo-btn"
                      onClick={() => {
                        setShowMenu(false);
                        setShowResetConfirmModal(true);
                      }}
                      className="w-full text-left px-3 py-2 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 flex items-center gap-2 cursor-pointer"
                    >
                      <RotateCcw className="w-3.5 h-3.5 text-slate-500" />
                      Reload Demo Dataset
                    </button>
                    <div className="my-1 border-t border-slate-100 dark:border-slate-700"></div>
                    <button
                      id="data-clear-all-btn"
                      onClick={() => {
                        setShowMenu(false);
                        setShowClearConfirmModal(true);
                      }}
                      className="w-full text-left px-3 py-2 text-xs text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 flex items-center gap-2 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      Clear All Activities
                    </button>
                  </div>
                )}
              </div>

              {/* Primary Add Activity Button */}
              <button
                id="header-log-activity-button"
                onClick={onOpenLogModal}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white text-xs sm:text-sm font-semibold shadow-sm shadow-emerald-600/25 transition cursor-pointer"
              >
                <Plus className="w-4 h-4 stroke-[2.5]" />
                <span>Log Activity</span>
              </button>
            </div>
          </div>
        </div>

        {/* Global Action Feedback Notification Toast */}
        {actionFeedback && (
          <div
            id="navbar-action-feedback-toast"
            className="bg-emerald-600 text-white text-xs font-semibold px-4 py-2 text-center flex items-center justify-center gap-2 shadow-xs animate-in slide-in-from-top duration-200"
          >
            <Check className="w-3.5 h-3.5 stroke-[3]" />
            <span>{actionFeedback}</span>
          </div>
        )}
      </header>

      {/* Export Modal */}
      {showExportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs">
          <div
            id="export-modal-card"
            className="w-full max-w-sm bg-white dark:bg-slate-800 rounded-2xl p-6 border border-slate-200 dark:border-slate-700 shadow-xl"
          >
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-display font-bold text-lg text-slate-900 dark:text-white">Export Activity Data</h3>
              <button
                id="close-export-modal-button"
                onClick={() => setShowExportModal(false)}
                className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
                title="Close dialog"
                aria-label="Close dialog"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {activities.length === 0 ? (
              <div className="py-4 text-center">
                <div className="w-10 h-10 rounded-full bg-slate-100 dark:bg-slate-700/60 text-slate-400 flex items-center justify-center mx-auto mb-3">
                  <Database className="w-5 h-5" />
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-300 font-medium">
                  No activities available to export.
                </p>
                <p className="text-[11px] text-slate-400 mt-1 mb-4">
                  Log an activity or reload the demo dataset to generate export files.
                </p>
                <button
                  id="export-empty-close-btn"
                  onClick={() => setShowExportModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-200 text-xs font-semibold cursor-pointer transition"
                >
                  Close
                </button>
              </div>
            ) : (
              <>
                <p className="text-xs text-slate-600 dark:text-slate-300 mb-5">
                  Download your complete carbon log ({activities.length} entries) for analysis in spreadsheets or personal archives.
                </p>
                <div className="space-y-3">
                  <button
                    id="export-csv-download-button"
                    onClick={exportCSV}
                    className="w-full flex items-center justify-between p-3.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:border-emerald-500 dark:hover:border-emerald-500 bg-slate-50 dark:bg-slate-900/50 hover:bg-emerald-50/50 dark:hover:bg-emerald-950/20 text-slate-900 dark:text-white text-xs font-semibold transition cursor-pointer"
                  >
                    <span className="flex items-center gap-2.5">
                      <FileSpreadsheet className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                      <span>Download Spreadsheet (.CSV)</span>
                    </span>
                    <span className="text-[11px] text-slate-400 font-normal">Excel / Sheets</span>
                  </button>
                  <button
                    id="export-json-download-button"
                    onClick={exportJSON}
                    className="w-full flex items-center justify-between p-3.5 rounded-xl border border-slate-200 dark:border-slate-700 hover:border-emerald-500 dark:hover:border-emerald-500 bg-slate-50 dark:bg-slate-900/50 hover:bg-emerald-50/50 dark:hover:bg-emerald-950/20 text-slate-900 dark:text-white text-xs font-semibold transition cursor-pointer"
                  >
                    <span className="flex items-center gap-2.5">
                      <FileJson className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                      <span>Download JSON Archive</span>
                    </span>
                    <span className="text-[11px] text-slate-400 font-normal">Raw Objects</span>
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* Reset Demo Dataset Confirmation Modal */}
      {showResetConfirmModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs">
          <div
            id="reset-confirm-modal-card"
            className="w-full max-w-sm bg-white dark:bg-slate-800 rounded-2xl p-6 border border-slate-200 dark:border-slate-700 shadow-xl"
          >
            <div className="w-10 h-10 rounded-xl bg-amber-100 dark:bg-amber-950/80 text-amber-600 dark:text-amber-400 flex items-center justify-center mb-3.5">
              <RotateCcw className="w-5 h-5" />
            </div>
            <h3 className="font-display font-bold text-base text-slate-900 dark:text-white">
              Reload Demo Dataset?
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-300 mt-2 mb-5 leading-relaxed">
              This will replace all currently recorded activities with the curated reference demo dataset across travel, energy, and food.
            </p>
            <div className="flex items-center justify-end gap-2.5">
              <button
                id="cancel-reset-demo-button"
                onClick={() => setShowResetConfirmModal(false)}
                className="px-3.5 py-2 rounded-xl text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                id="confirm-reset-demo-button"
                onClick={handleConfirmReset}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white transition cursor-pointer shadow-xs"
              >
                Reload Demo Data
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Clear All Activities Confirmation Modal (Replaces browser window.confirm) */}
      {showClearConfirmModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-xs">
          <div
            id="clear-confirm-modal-card"
            className="w-full max-w-sm bg-white dark:bg-slate-800 rounded-2xl p-6 border border-slate-200 dark:border-slate-700 shadow-xl"
          >
            <div className="w-10 h-10 rounded-xl bg-rose-100 dark:bg-rose-950/80 text-rose-600 dark:text-rose-400 flex items-center justify-center mb-3.5">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <h3 className="font-display font-bold text-base text-slate-900 dark:text-white">
              Clear All Activities?
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-300 mt-2 mb-5 leading-relaxed">
              Are you sure you want to permanently clear all {activities.length} activity records? Your weekly target budget goal will remain preserved.
            </p>
            <div className="flex items-center justify-end gap-2.5">
              <button
                id="cancel-clear-all-button"
                onClick={() => setShowClearConfirmModal(false)}
                className="px-3.5 py-2 rounded-xl text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                id="confirm-clear-all-button"
                onClick={handleConfirmClearAll}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-rose-600 hover:bg-rose-700 text-white transition cursor-pointer shadow-xs"
              >
                Yes, Clear All
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
