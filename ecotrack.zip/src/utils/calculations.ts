import {
  ACTIVITY_CONFIGS,
  ActivityCategory,
  ActivityType,
  CarbonActivity,
  DateRangePreset,
  StreakBadge,
  WeekStreakRecord,
  WeeklyStreakSummary,
  BadgeTier,
  MonthTrendData,
  QuarterlyTrendData,
  AnnualMonthlyTrendSummary,
} from '../types';

/**
 * Calculates emissions in kg CO2 based on activity type and quantity
 */
export function calculateEmissions(type: ActivityType, quantity: number): number {
  if (quantity <= 0 || isNaN(quantity)) return 0;
  const config = ACTIVITY_CONFIGS[type];
  if (!config) return 0;
  const raw = quantity * config.conversionFactor;
  // Round to 2 decimal places cleanly
  return Math.round(raw * 100) / 100;
}

/**
 * Returns Monday 00:00:00 to Sunday 23:59:59 for the calendar week of the given date
 */
export function getCalendarWeekRange(refDate = new Date()): { start: Date; end: Date } {
  const date = new Date(refDate);
  const day = date.getDay(); // 0 is Sunday, 1 is Monday ... 6 is Saturday
  // Distance to previous Monday: if day === 0 (Sunday), diff is -6 days. Otherwise 1 - day
  const diffToMonday = day === 0 ? -6 : 1 - day;

  const monday = new Date(date);
  monday.setDate(date.getDate() + diffToMonday);
  monday.setHours(0, 0, 0, 0);

  const sunday = new Date(monday);
  sunday.setDate(monday.getDate() + 6);
  sunday.setHours(23, 59, 59, 999);

  return { start: monday, end: sunday };
}

/**
 * Formats a Date object to YYYY-MM-DD local string
 */
export function toLocalDateString(date: Date): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * Formats date and time nicely for display
 */
export function formatActivityDate(isoString: string): {
  relative: string;
  fullDate: string;
  time: string;
} {
  try {
    const d = new Date(isoString);
    if (isNaN(d.getTime())) {
      return { relative: 'Unknown', fullDate: isoString, time: '' };
    }
    const today = new Date();
    const isToday =
      d.getDate() === today.getDate() &&
      d.getMonth() === today.getMonth() &&
      d.getFullYear() === today.getFullYear();

    const yesterday = new Date(today);
    yesterday.setDate(today.getDate() - 1);
    const isYesterday =
      d.getDate() === yesterday.getDate() &&
      d.getMonth() === yesterday.getMonth() &&
      d.getFullYear() === yesterday.getFullYear();

    const time = d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const fullDate = d.toLocaleDateString([], {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });

    let relative = fullDate;
    if (isToday) relative = `Today at ${time}`;
    else if (isYesterday) relative = `Yesterday at ${time}`;

    return { relative, fullDate, time };
  } catch {
    return { relative: isoString, fullDate: isoString, time: '' };
  }
}

/**
 * Filter activities by category, date range preset, or search
 */
export function filterActivities(
  activities: CarbonActivity[],
  categoryFilter: 'all' | ActivityCategory,
  datePreset: DateRangePreset,
  customStart?: string,
  customEnd?: string,
  searchQuery?: string
): CarbonActivity[] {
  const now = new Date();
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0);
  const todayEnd = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59, 999);

  const { start: weekStart, end: weekEnd } = getCalendarWeekRange(now);

  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1, 0, 0, 0, 0);
  const monthEnd = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999);

  return activities.filter((act) => {
    // Category check
    if (categoryFilter !== 'all' && act.category !== categoryFilter) {
      return false;
    }

    const actDate = new Date(act.timestamp);

    // Date preset check
    if (datePreset === 'today') {
      if (actDate < todayStart || actDate > todayEnd) return false;
    } else if (datePreset === 'this_week') {
      if (actDate < weekStart || actDate > weekEnd) return false;
    } else if (datePreset === 'this_month') {
      if (actDate < monthStart || actDate > monthEnd) return false;
    } else if (datePreset === 'custom') {
      if (customStart) {
        const start = new Date(customStart);
        start.setHours(0, 0, 0, 0);
        if (actDate < start) return false;
      }
      if (customEnd) {
        const end = new Date(customEnd);
        end.setHours(23, 59, 59, 999);
        if (actDate > end) return false;
      }
    }

    // Search query check (activity name, type, category, notes, quantity)
    if (searchQuery && searchQuery.trim().length > 0) {
      const q = searchQuery.toLowerCase().trim();
      const config = ACTIVITY_CONFIGS[act.type];
      const matchName = config?.label.toLowerCase().includes(q) || act.type.toLowerCase().includes(q);
      const matchCategory = config?.categoryLabel.toLowerCase().includes(q) || act.category.toLowerCase().includes(q);
      const matchNote = Boolean(act.note && act.note.toLowerCase().includes(q));
      const matchQuantity = `${act.quantity} ${config?.unit || ''}`.toLowerCase().includes(q);
      if (!matchName && !matchCategory && !matchNote && !matchQuantity) {
        return false;
      }
    }

    return true;
  });
}

export interface CategoryStat {
  category: ActivityCategory;
  label: string;
  totalKg: number;
  percentage: number;
  color: string;
  count: number;
}

export interface DashboardMetrics {
  totalLifetimeKg: number;
  currentWeekKg: number;
  dailyAverageKg: number;
  activeWeekPercentage: number;
  weeklyTargetStatus: 'normal' | 'warning' | 'exceeded';
  remainingWeeklyBudgetKg: number;
  categoryBreakdown: CategoryStat[];
  daysRemainingInWeek: number;
  activeDaysCount: number;
  treesEquivalent: number;
}

/**
 * Computes all aggregate stats and metrics
 */
export function computeDashboardMetrics(
  activities: CarbonActivity[],
  targetKg: number
): DashboardMetrics {
  const now = new Date();
  const { start: weekStart, end: weekEnd } = getCalendarWeekRange(now);

  let totalLifetime = 0;
  let currentWeekTotal = 0;
  const uniqueDates = new Set<string>();

  const categoryTotals: Record<ActivityCategory, { totalKg: number; count: number }> = {
    travel: { totalKg: 0, count: 0 },
    energy: { totalKg: 0, count: 0 },
    food: { totalKg: 0, count: 0 },
  };

  activities.forEach((act) => {
    const actDate = new Date(act.timestamp);
    const kg = act.emissionsKg || 0;
    totalLifetime += kg;

    // Track unique days logged
    const dayKey = `${actDate.getFullYear()}-${actDate.getMonth() + 1}-${actDate.getDate()}`;
    uniqueDates.add(dayKey);

    // Current calendar week check (Monday-Sunday)
    if (actDate >= weekStart && actDate <= weekEnd) {
      currentWeekTotal += kg;
    }

    // Category breakdown
    if (categoryTotals[act.category]) {
      categoryTotals[act.category].totalKg += kg;
      categoryTotals[act.category].count += 1;
    }
  });

  totalLifetime = Math.round(totalLifetime * 100) / 100;
  currentWeekTotal = Math.round(currentWeekTotal * 100) / 100;

  // Daily average: divide by logged unique days (or 1 if 0)
  const activeDaysCount = Math.max(1, uniqueDates.size);
  const dailyAverageKg = Math.round((totalLifetime / activeDaysCount) * 100) / 100;

  // Target progress & status
  const safeTarget = Math.max(1, targetKg);
  const activeWeekPercentage = Math.round((currentWeekTotal / safeTarget) * 100);

  let weeklyTargetStatus: 'normal' | 'warning' | 'exceeded' = 'normal';
  if (activeWeekPercentage >= 100) {
    weeklyTargetStatus = 'exceeded';
  } else if (activeWeekPercentage >= 80) {
    weeklyTargetStatus = 'warning';
  }

  const remainingWeeklyBudgetKg = Math.round((safeTarget - currentWeekTotal) * 100) / 100;

  // Category stats with percentage
  const categoryConfig: Record<ActivityCategory, { label: string; color: string }> = {
    travel: { label: 'Travel & Transport', color: '#0284c7' }, // Sky
    energy: { label: 'Home & Energy', color: '#d97706' },     // Amber
    food: { label: 'Diet & Food', color: '#16a34a' },         // Green
  };

  const categoryBreakdown: CategoryStat[] = (['travel', 'energy', 'food'] as ActivityCategory[]).map(
    (cat) => {
      const catData = categoryTotals[cat];
      const catTotal = Math.round(catData.totalKg * 100) / 100;
      const percentage =
        totalLifetime > 0 ? Math.round((catTotal / totalLifetime) * 100) : 0;

      return {
        category: cat,
        label: categoryConfig[cat].label,
        totalKg: catTotal,
        percentage,
        color: categoryConfig[cat].color,
        count: catData.count,
      };
    }
  );

  // Days remaining in week until Sunday
  const todayDay = now.getDay(); // 0 is Sunday
  const daysRemainingInWeek = todayDay === 0 ? 0 : 7 - todayDay;

  // One urban mature tree absorbs approx 22 kg CO2 per year (~0.06 kg per day)
  const treesEquivalent = Math.round((totalLifetime / 22) * 10) / 10;

  return {
    totalLifetimeKg: totalLifetime,
    currentWeekKg: currentWeekTotal,
    dailyAverageKg,
    activeWeekPercentage,
    weeklyTargetStatus,
    remainingWeeklyBudgetKg,
    categoryBreakdown,
    daysRemainingInWeek,
    activeDaysCount,
    treesEquivalent,
  };
}

/**
 * Returns emissions for the current week's 7 days (Monday through Sunday)
 */
export function getWeeklyDailyDistribution(
  activities: CarbonActivity[],
  refDate = new Date()
): { dayName: string; shortDate: string; dateStr: string; totalKg: number; isToday: boolean }[] {
  const { start: weekStart } = getCalendarWeekRange(refDate);
  const now = new Date();
  const todayStr = toLocalDateString(now);

  const days: { dayName: string; shortDate: string; dateStr: string; totalKg: number; isToday: boolean }[] = [];
  const dayNames = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

  for (let i = 0; i < 7; i++) {
    const d = new Date(weekStart);
    d.setDate(weekStart.getDate() + i);
    const dateStr = toLocalDateString(d);
    const shortDate = `${d.getMonth() + 1}/${d.getDate()}`;

    // Sum activities on this date
    let dayTotal = 0;
    activities.forEach((act) => {
      const actDateStr = toLocalDateString(new Date(act.timestamp));
      if (actDateStr === dateStr) {
        dayTotal += act.emissionsKg || 0;
      }
    });

    days.push({
      dayName: dayNames[i],
      shortDate,
      dateStr,
      totalKg: Math.round(dayTotal * 100) / 100,
      isToday: dateStr === todayStr,
    });
  }

  return days;
}

/**
 * Returns Monday 00:00:00 to Sunday 23:59:59 for the calendar week preceding the given date
 */
export function getPreviousWeekRange(refDate = new Date()): { start: Date; end: Date } {
  const currentRange = getCalendarWeekRange(refDate);
  const prevMonday = new Date(currentRange.start);
  prevMonday.setDate(prevMonday.getDate() - 7);
  prevMonday.setHours(0, 0, 0, 0);

  const prevSunday = new Date(prevMonday);
  prevSunday.setDate(prevMonday.getDate() + 6);
  prevSunday.setHours(23, 59, 59, 999);

  return { start: prevMonday, end: prevSunday };
}

/**
 * Calculates total CO2 emissions for the previous calendar week
 */
export function getPreviousWeekTotal(activities: CarbonActivity[], refDate = new Date()): number {
  const { start: prevStart, end: prevEnd } = getPreviousWeekRange(refDate);
  let total = 0;
  activities.forEach((act) => {
    const actDate = new Date(act.timestamp);
    if (actDate >= prevStart && actDate <= prevEnd) {
      total += act.emissionsKg || 0;
    }
  });
  return Math.round(total * 100) / 100;
}

export interface WeekComparisonMetrics {
  currentWeekTotalKg: number;
  previousWeekTotalKg: number;
  differenceKg: number; // positive = increase, negative = decrease
  percentageChange: number | null; // e.g., -14.2% or +25.0%
  isReduction: boolean;
  currentWeekRangeLabel: string;
  previousWeekRangeLabel: string;
  categoryComparison: {
    category: ActivityCategory;
    label: string;
    color: string;
    currentKg: number;
    previousKg: number;
    diffKg: number;
  }[];
  dayComparison: {
    dayName: string;
    currentDateStr: string;
    previousDateStr: string;
    currentKg: number;
    previousKg: number;
  }[];
}

/**
 * Computes detailed comparison metrics between the current week and the previous week
 */
export function getWeekComparison(
  activities: CarbonActivity[],
  refDate = new Date()
): WeekComparisonMetrics {
  const currentRange = getCalendarWeekRange(refDate);
  const prevRange = getPreviousWeekRange(refDate);

  let currentTotal = 0;
  let previousTotal = 0;

  const currentCategoryTotals: Record<ActivityCategory, number> = {
    travel: 0,
    energy: 0,
    food: 0,
  };
  const previousCategoryTotals: Record<ActivityCategory, number> = {
    travel: 0,
    energy: 0,
    food: 0,
  };

  activities.forEach((act) => {
    const actDate = new Date(act.timestamp);
    const kg = act.emissionsKg || 0;

    if (actDate >= currentRange.start && actDate <= currentRange.end) {
      currentTotal += kg;
      if (currentCategoryTotals[act.category] !== undefined) {
        currentCategoryTotals[act.category] += kg;
      }
    } else if (actDate >= prevRange.start && actDate <= prevRange.end) {
      previousTotal += kg;
      if (previousCategoryTotals[act.category] !== undefined) {
        previousCategoryTotals[act.category] += kg;
      }
    }
  });

  currentTotal = Math.round(currentTotal * 100) / 100;
  previousTotal = Math.round(previousTotal * 100) / 100;
  const differenceKg = Math.round((currentTotal - previousTotal) * 100) / 100;

  let percentageChange: number | null = null;
  if (previousTotal > 0) {
    percentageChange = Math.round(((currentTotal - previousTotal) / previousTotal) * 1000) / 10;
  } else if (currentTotal > 0) {
    percentageChange = 100;
  }

  const formatShortRange = (start: Date, end: Date) => {
    const startStr = start.toLocaleDateString([], { month: 'short', day: 'numeric' });
    const endStr = end.toLocaleDateString([], { month: 'short', day: 'numeric' });
    return `${startStr} – ${endStr}`;
  };

  const categoryConfig: Record<ActivityCategory, { label: string; color: string }> = {
    travel: { label: 'Travel', color: '#0284c7' },
    energy: { label: 'Energy', color: '#d97706' },
    food: { label: 'Food', color: '#16a34a' },
  };

  const categoryComparison = (['travel', 'energy', 'food'] as ActivityCategory[]).map((cat) => {
    const cur = Math.round(currentCategoryTotals[cat] * 100) / 100;
    const prev = Math.round(previousCategoryTotals[cat] * 100) / 100;
    return {
      category: cat,
      label: categoryConfig[cat].label,
      color: categoryConfig[cat].color,
      currentKg: cur,
      previousKg: prev,
      diffKg: Math.round((cur - prev) * 100) / 100,
    };
  });

  const dayNames = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const dayComparison: {
    dayName: string;
    currentDateStr: string;
    previousDateStr: string;
    currentKg: number;
    previousKg: number;
  }[] = [];

  for (let i = 0; i < 7; i++) {
    const curDay = new Date(currentRange.start);
    curDay.setDate(curDay.getDate() + i);
    const curDateStr = toLocalDateString(curDay);

    const prevDay = new Date(prevRange.start);
    prevDay.setDate(prevDay.getDate() + i);
    const prevDateStr = toLocalDateString(prevDay);

    let curDayTotal = 0;
    let prevDayTotal = 0;

    activities.forEach((act) => {
      const actDateStr = toLocalDateString(new Date(act.timestamp));
      if (actDateStr === curDateStr) {
        curDayTotal += act.emissionsKg || 0;
      }
      if (actDateStr === prevDateStr) {
        prevDayTotal += act.emissionsKg || 0;
      }
    });

    dayComparison.push({
      dayName: dayNames[i],
      currentDateStr: curDateStr,
      previousDateStr: prevDateStr,
      currentKg: Math.round(curDayTotal * 100) / 100,
      previousKg: Math.round(prevDayTotal * 100) / 100,
    });
  }

  return {
    currentWeekTotalKg: currentTotal,
    previousWeekTotalKg: previousTotal,
    differenceKg,
    percentageChange,
    isReduction: currentTotal < previousTotal,
    currentWeekRangeLabel: formatShortRange(currentRange.start, currentRange.end),
    previousWeekRangeLabel: formatShortRange(prevRange.start, prevRange.end),
    categoryComparison,
    dayComparison,
  };
}

export const DEFAULT_STREAK_BADGES: Omit<StreakBadge, 'isUnlocked' | 'unlockedAtStreak'>[] = [
  {
    id: 'badge-1-sprout',
    name: 'Green Sprout',
    tier: 'bronze',
    requiredWeeks: 1,
    description: 'Kept emissions within your weekly budget for 1 full week.',
    icon: 'Sprout',
  },
  {
    id: 'badge-2-steady',
    name: 'Eco Consistent',
    tier: 'silver',
    requiredWeeks: 2,
    description: 'Maintained your weekly emission goal for 2 consecutive weeks.',
    icon: 'Leaf',
  },
  {
    id: 'badge-3-champion',
    name: 'Climate Champion',
    tier: 'gold',
    requiredWeeks: 3,
    description: 'Beat your weekly carbon reduction limit for 3 consecutive weeks.',
    icon: 'Flame',
  },
  {
    id: 'badge-4-guardian',
    name: 'Carbon Guardian',
    tier: 'platinum',
    requiredWeeks: 4,
    description: 'One full month (4 consecutive weeks) of sustainable carbon budgeting.',
    icon: 'ShieldCheck',
  },
  {
    id: 'badge-6-hero',
    name: 'Planet Hero',
    tier: 'diamond',
    requiredWeeks: 6,
    description: 'Outstanding stewardship: 6 consecutive weeks strictly under your target limit.',
    icon: 'Globe',
  },
  {
    id: 'badge-8-master',
    name: 'Master of Balance',
    tier: 'legendary',
    requiredWeeks: 8,
    description: 'Legendary eco-discipline: 8 or more consecutive weeks under your carbon limit.',
    icon: 'Award',
  },
];

/**
 * Computes weekly goal streak metrics, historical pass/fail records, and rewards/badges
 */
export function computeWeeklyStreakSummary(
  activities: CarbonActivity[],
  weeklyTarget: number,
  refDate = new Date(),
  weeksToAudit = 8
): WeeklyStreakSummary {
  const currentWeekRange = getCalendarWeekRange(refDate);
  const weekRecords: WeekStreakRecord[] = [];

  // Generate week records from weekOffset 0 (current) back to weeksToAudit - 1
  for (let offset = 0; offset < weeksToAudit; offset++) {
    const monday = new Date(currentWeekRange.start);
    monday.setDate(monday.getDate() - offset * 7);
    monday.setHours(0, 0, 0, 0);

    const sunday = new Date(monday);
    sunday.setDate(monday.getDate() + 6);
    sunday.setHours(23, 59, 59, 999);

    let totalKg = 0;
    let count = 0;

    activities.forEach((act) => {
      const actDate = new Date(act.timestamp);
      if (actDate >= monday && actDate <= sunday) {
        totalKg += act.emissionsKg || 0;
        count++;
      }
    });

    totalKg = Math.round(totalKg * 100) / 100;
    const isUnderLimit = totalKg <= weeklyTarget;
    const isCurrentWeek = offset === 0;

    let status: 'passed' | 'failed' | 'in_progress';
    if (isCurrentWeek) {
      status = isUnderLimit ? 'in_progress' : 'failed';
    } else {
      status = isUnderLimit ? 'passed' : 'failed';
    }

    const startLabel = monday.toLocaleDateString([], { month: 'short', day: 'numeric' });
    const endLabel = sunday.toLocaleDateString([], { month: 'short', day: 'numeric' });

    weekRecords.push({
      weekOffset: offset,
      startDate: monday.toISOString(),
      endDate: sunday.toISOString(),
      label: `${startLabel} – ${endLabel}`,
      totalEmissionsKg: totalKg,
      targetKg: weeklyTarget,
      isUnderLimit,
      isCurrentWeek,
      activitiesCount: count,
      status,
    });
  }

  const currentWeekRecord = weekRecords[0];
  const currentWeekKg = currentWeekRecord ? currentWeekRecord.totalEmissionsKg : 0;
  const isCurrentWeekUnderLimit = currentWeekKg <= weeklyTarget;
  const currentWeekRemainingKg = Math.max(0, Math.round((weeklyTarget - currentWeekKg) * 100) / 100);

  // Calculate completed streak from past weeks (offset 1, 2, 3...)
  let completedStreak = 0;
  for (let i = 1; i < weekRecords.length; i++) {
    const record = weekRecords[i];
    // A week is successful if it was under target
    if (record.isUnderLimit) {
      completedStreak++;
    } else {
      break;
    }
  }

  // Current streak accounts for current week status
  let currentStreak = 0;
  if (!isCurrentWeekUnderLimit) {
    // Current week exceeded target -> active streak broken
    currentStreak = 0;
  } else if (currentWeekRecord.activitiesCount > 0) {
    // Current week has activities and is within target -> extends streak
    currentStreak = completedStreak + 1;
  } else {
    // Current week has no activities yet, but is under limit -> maintains completed streak
    currentStreak = completedStreak;
  }

  // Calculate longest historical streak across all audited weeks (chronological order)
  let longestStreak = 0;
  let runningStreak = 0;
  // Reverse chronological to chronological (oldest to newest)
  const chronological = [...weekRecords].reverse();
  chronological.forEach((rec) => {
    if (rec.isUnderLimit) {
      runningStreak++;
      if (runningStreak > longestStreak) {
        longestStreak = runningStreak;
      }
    } else {
      runningStreak = 0;
    }
  });

  longestStreak = Math.max(longestStreak, currentStreak, completedStreak);

  // Badges evaluation based on best achieved or active streak
  const bestStreak = Math.max(currentStreak, longestStreak);
  const badges: StreakBadge[] = DEFAULT_STREAK_BADGES.map((badgeDef) => {
    const isUnlocked = bestStreak >= badgeDef.requiredWeeks;
    return {
      ...badgeDef,
      isUnlocked,
      unlockedAtStreak: isUnlocked ? badgeDef.requiredWeeks : undefined,
    };
  });

  const nextBadge = badges.find((b) => !b.isUnlocked) || null;
  const weeksUntilNextBadge = nextBadge
    ? Math.max(1, nextBadge.requiredWeeks - currentStreak)
    : 0;

  return {
    currentStreak,
    completedStreak,
    isCurrentWeekUnderLimit,
    currentWeekKg,
    currentWeekRemainingKg,
    longestStreak,
    recentWeeks: weekRecords,
    badges,
    nextBadge,
    weeksUntilNextBadge,
  };
}

/**
 * Computes monthly CO2 emission trends across the 12 calendar months for a given year,
 * including category breakdowns, quarterly aggregates, monthly target budgets, and seasonal insights.
 */
export function computeMonthlyEmissionTrends(
  activities: CarbonActivity[],
  weeklyTarget: number,
  targetYear?: number
): AnnualMonthlyTrendSummary {
  const now = new Date();
  const currentCalendarYear = now.getFullYear();
  const currentCalendarMonth = now.getMonth(); // 0..11

  // Discover all distinct years present in the activity history
  const yearSet = new Set<number>();
  yearSet.add(currentCalendarYear);

  activities.forEach((act) => {
    try {
      const d = new Date(act.timestamp);
      if (!isNaN(d.getTime())) {
        yearSet.add(d.getFullYear());
      }
    } catch {
      // Ignore invalid dates
    }
  });

  const availableYears = Array.from(yearSet).sort((a, b) => b - a);
  const activeYear = targetYear && yearSet.has(targetYear) ? targetYear : availableYears[0] || currentCalendarYear;

  const monthShortNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const monthFullNames = [
    'January',
    'February',
    'March',
    'April',
    'May',
    'June',
    'July',
    'August',
    'September',
    'October',
    'November',
    'December',
  ];

  // Month-by-month compilation
  const months: MonthTrendData[] = [];

  for (let m = 0; m < 12; m++) {
    const isCurrentMonth = activeYear === currentCalendarYear && m === currentCalendarMonth;
    const isFutureMonth =
      activeYear > currentCalendarYear || (activeYear === currentCalendarYear && m > currentCalendarMonth);

    // Date range boundaries for month m
    const monthStart = new Date(activeYear, m, 1, 0, 0, 0, 0);
    const monthEnd = new Date(activeYear, m + 1, 0, 23, 59, 59, 999);
    const daysInMonth = monthEnd.getDate();

    // Monthly budget dynamically scaled to the number of days (weeks = days / 7)
    const monthBudgetKg = Math.round((weeklyTarget * (daysInMonth / 7)) * 10) / 10;

    let totalKg = 0;
    let travelKg = 0;
    let energyKg = 0;
    let foodKg = 0;
    let activityCount = 0;

    activities.forEach((act) => {
      try {
        const actDate = new Date(act.timestamp);
        if (actDate >= monthStart && actDate <= monthEnd) {
          const kg = act.emissionsKg || 0;
          totalKg += kg;
          activityCount++;
          if (act.category === 'travel') travelKg += kg;
          else if (act.category === 'energy') energyKg += kg;
          else if (act.category === 'food') foodKg += kg;
        }
      } catch {
        // Ignore unparseable entries
      }
    });

    totalKg = Math.round(totalKg * 100) / 100;
    travelKg = Math.round(travelKg * 100) / 100;
    energyKg = Math.round(energyKg * 100) / 100;
    foodKg = Math.round(foodKg * 100) / 100;
    const varianceFromBudgetKg = Math.round((totalKg - monthBudgetKg) * 100) / 100;

    months.push({
      monthIndex: m,
      monthShort: monthShortNames[m],
      monthFull: monthFullNames[m],
      year: activeYear,
      totalKg,
      travelKg,
      energyKg,
      foodKg,
      activityCount,
      budgetKg: monthBudgetKg,
      isCurrentMonth,
      isFutureMonth,
      varianceFromBudgetKg,
      changeFromPrevMonthKg: null,
      changeFromPrevMonthPercent: null,
    });
  }

  // Calculate Month-Over-Month delta comparisons
  for (let m = 1; m < 12; m++) {
    const curr = months[m];
    const prev = months[m - 1];

    if (!curr.isFutureMonth && (curr.activityCount > 0 || prev.activityCount > 0)) {
      const diff = Math.round((curr.totalKg - prev.totalKg) * 100) / 100;
      curr.changeFromPrevMonthKg = diff;
      if (prev.totalKg > 0) {
        curr.changeFromPrevMonthPercent = Math.round(((curr.totalKg - prev.totalKg) / prev.totalKg) * 100);
      }
    }
  }

  // Year totals & averages
  const totalYearKg = Math.round(months.reduce((sum, m) => sum + m.totalKg, 0) * 100) / 100;

  // Active months for average calculation (past and current months)
  const elapsedMonths = months.filter((m) => !m.isFutureMonth);
  const monthsWithData = months.filter((m) => m.totalKg > 0);
  const activeMonthsCount = Math.max(1, elapsedMonths.length);
  const monthlyAverageKg = Math.round((totalYearKg / activeMonthsCount) * 100) / 100;

  // Peak month
  let peakMonth: MonthTrendData | null = null;
  if (monthsWithData.length > 0) {
    peakMonth = [...monthsWithData].sort((a, b) => b.totalKg - a.totalKg)[0] || null;
  }

  // Lowest month with recorded activities
  let lowestActiveMonth: MonthTrendData | null = null;
  if (monthsWithData.length > 0) {
    lowestActiveMonth = [...monthsWithData].sort((a, b) => a.totalKg - b.totalKg)[0] || null;
  }

  // Annual budget baseline (52 weeks)
  const annualBudgetKg = Math.round(weeklyTarget * 52 * 10) / 10;

  // Quarterly aggregation
  const quarterDefs = [
    { quarter: 'Q1' as const, label: 'Q1 (Jan – Mar)', start: 0, end: 2 },
    { quarter: 'Q2' as const, label: 'Q2 (Apr – Jun)', start: 3, end: 5 },
    { quarter: 'Q3' as const, label: 'Q3 (Jul – Sep)', start: 6, end: 8 },
    { quarter: 'Q4' as const, label: 'Q4 (Oct – Dec)', start: 9, end: 11 },
  ];

  const quarterly: QuarterlyTrendData[] = quarterDefs.map((q) => {
    const qMonths = months.slice(q.start, q.end + 1);
    const totalKg = Math.round(qMonths.reduce((s, m) => s + m.totalKg, 0) * 100) / 100;
    const travelKg = Math.round(qMonths.reduce((s, m) => s + m.travelKg, 0) * 100) / 100;
    const energyKg = Math.round(qMonths.reduce((s, m) => s + m.energyKg, 0) * 100) / 100;
    const foodKg = Math.round(qMonths.reduce((s, m) => s + m.foodKg, 0) * 100) / 100;
    const budgetKg = Math.round(qMonths.reduce((s, m) => s + m.budgetKg, 0) * 10) / 10;
    const monthlyAverageKg = Math.round((totalKg / 3) * 100) / 100;

    return {
      quarter: q.quarter,
      label: q.label,
      totalKg,
      travelKg,
      energyKg,
      foodKg,
      monthlyAverageKg,
      budgetKg,
    };
  });

  // Generate an intelligent seasonal insight based on actual aggregated data
  let seasonalityInsight = 'Log activities across the year to unlock seasonal carbon footprint insights.';
  if (totalYearKg > 0) {
    const activeQuarters = quarterly.filter((q) => q.totalKg > 0);
    const topQuarter = [...activeQuarters].sort((a, b) => b.totalKg - a.totalKg)[0];

    const categoryYearTotals = {
      travel: months.reduce((s, m) => s + m.travelKg, 0),
      energy: months.reduce((s, m) => s + m.energyKg, 0),
      food: months.reduce((s, m) => s + m.foodKg, 0),
    };

    const topCategoryKey = (Object.keys(categoryYearTotals) as ActivityCategory[]).sort(
      (a, b) => categoryYearTotals[b] - categoryYearTotals[a]
    )[0];

    const topCategoryPercent = Math.round((categoryYearTotals[topCategoryKey] / totalYearKg) * 100);

    if (topQuarter) {
      seasonalityInsight = `${topQuarter.label} had your highest cumulative emissions (${topQuarter.totalKg} kg CO₂), with ${topCategoryKey} driving ${topCategoryPercent}% of overall footprint.`;
    } else {
      seasonalityInsight = `Your monthly average is currently ${monthlyAverageKg} kg CO₂, with ${topCategoryKey} being the dominant emission contributor.`;
    }
  }

  return {
    year: activeYear,
    months,
    quarterly,
    totalYearKg,
    activeMonthsCount,
    monthlyAverageKg,
    peakMonth,
    lowestActiveMonth,
    annualBudgetKg,
    availableYears,
    seasonalityInsight,
  };
}
