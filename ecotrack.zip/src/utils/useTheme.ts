import { useState, useEffect, useCallback } from 'react';
import { ThemePreference } from '../types';

export const STORAGE_KEY_THEME_PREF = 'ecotrack_theme_preference_v1';
export const STORAGE_KEY_THEME_LEGACY = 'ecotrack_theme_v1';

/**
 * Returns true if the system OS currently prefers dark mode.
 */
function getSystemPrefersDark(): boolean {
  if (typeof window === 'undefined' || !window.matchMedia) {
    return false;
  }
  return window.matchMedia('(prefers-color-scheme: dark)').matches;
}

/**
 * Retrieves the stored theme preference from localStorage or defaults to 'system'.
 */
function getInitialThemePreference(): ThemePreference {
  try {
    const storedPref = localStorage.getItem(STORAGE_KEY_THEME_PREF);
    if (storedPref === 'light' || storedPref === 'dark' || storedPref === 'system') {
      return storedPref;
    }
    // Backward compatibility with legacy boolean 'dark'/'light'
    const legacy = localStorage.getItem(STORAGE_KEY_THEME_LEGACY);
    if (legacy === 'dark') return 'dark';
    if (legacy === 'light') return 'light';
  } catch (err) {
    console.error('Error reading theme from localStorage', err);
  }
  return 'system';
}

/**
 * Hook to manage user theme preference (light, dark, system).
 * Persists to localStorage, synchronizes with system preference changes,
 * syncs across multiple tabs, and applies the '.dark' class to <html> for Tailwind CSS.
 */
export function useTheme() {
  const [preference, setPreferenceState] = useState<ThemePreference>(getInitialThemePreference);
  const [systemDark, setSystemDark] = useState<boolean>(getSystemPrefersDark);

  // Compute resolved dark mode status
  const isDark = preference === 'dark' || (preference === 'system' && systemDark);

  // Apply .dark class to root element and persist to storage
  useEffect(() => {
    const root = document.documentElement;
    if (isDark) {
      root.classList.add('dark');
      root.setAttribute('data-theme', 'dark');
      root.style.colorScheme = 'dark';
    } else {
      root.classList.remove('dark');
      root.setAttribute('data-theme', 'light');
      root.style.colorScheme = 'light';
    }

    try {
      localStorage.setItem(STORAGE_KEY_THEME_PREF, preference);
      localStorage.setItem(STORAGE_KEY_THEME_LEGACY, isDark ? 'dark' : 'light');
    } catch (err) {
      console.error('Error persisting theme preference', err);
    }
  }, [isDark, preference]);

  // Listen to OS system color scheme changes
  useEffect(() => {
    if (typeof window === 'undefined' || !window.matchMedia) return;

    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    const handleMediaChange = (e: MediaQueryListEvent) => {
      setSystemDark(e.matches);
    };

    // Modern API with backward support
    if (mediaQuery.addEventListener) {
      mediaQuery.addEventListener('change', handleMediaChange);
    } else {
      mediaQuery.addListener(handleMediaChange);
    }

    return () => {
      if (mediaQuery.removeEventListener) {
        mediaQuery.removeEventListener('change', handleMediaChange);
      } else {
        mediaQuery.removeListener(handleMediaChange);
      }
    };
  }, []);

  // Listen to storage events for multi-tab synchronization
  useEffect(() => {
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === STORAGE_KEY_THEME_PREF && e.newValue) {
        if (e.newValue === 'light' || e.newValue === 'dark' || e.newValue === 'system') {
          setPreferenceState(e.newValue);
        }
      }
    };

    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, []);

  const setThemePreference = useCallback((newPref: ThemePreference) => {
    setPreferenceState(newPref);
  }, []);

  const toggleTheme = useCallback(() => {
    setPreferenceState((current) => {
      if (current === 'system') {
        // Toggle opposite of current system state
        return systemDark ? 'light' : 'dark';
      }
      return current === 'dark' ? 'light' : 'dark';
    });
  }, [systemDark]);

  return {
    preference,
    isDark,
    systemDark,
    setThemePreference,
    toggleTheme,
  };
}
