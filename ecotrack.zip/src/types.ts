export type ActivityCategory = 'travel' | 'energy' | 'food';

export type ActivityType =
  | 'car'
  | 'bus'
  | 'electricity'
  | 'veg_meal'
  | 'non_veg_meal';

export interface ActivityConfig {
  type: ActivityType;
  label: string;
  category: ActivityCategory;
  categoryLabel: string;
  conversionFactor: number; // kg CO2 per unit
  unit: string;
  unitLabel: string;
  defaultQuantity: number;
  iconName: string;
  color: string;
  bgLight: string;
  bgDark: string;
  borderColor: string;
  description: string;
}

export const ACTIVITY_CONFIGS: Record<ActivityType, ActivityConfig> = {
  car: {
    type: 'car',
    label: 'Car Travel',
    category: 'travel',
    categoryLabel: 'Travel',
    conversionFactor: 0.20,
    unit: 'km',
    unitLabel: 'Kilometers (km)',
    defaultQuantity: 15,
    iconName: 'Car',
    color: '#0284c7', // sky-600
    bgLight: 'bg-sky-50 text-sky-700 border-sky-200',
    bgDark: 'dark:bg-sky-950/40 dark:text-sky-300 dark:border-sky-800',
    borderColor: 'border-sky-500',
    description: 'Gasoline/diesel vehicle travel (0.20 kg CO₂ / km)',
  },
  bus: {
    type: 'bus',
    label: 'Public Transit (Bus)',
    category: 'travel',
    categoryLabel: 'Travel',
    conversionFactor: 0.08,
    unit: 'km',
    unitLabel: 'Kilometers (km)',
    defaultQuantity: 10,
    iconName: 'Bus',
    color: '#0d9488', // teal-600
    bgLight: 'bg-teal-50 text-teal-700 border-teal-200',
    bgDark: 'dark:bg-teal-950/40 dark:text-teal-300 dark:border-teal-800',
    borderColor: 'border-teal-500',
    description: 'Shared bus transit (0.08 kg CO₂ / km)',
  },
  electricity: {
    type: 'electricity',
    label: 'Electricity Usage',
    category: 'energy',
    categoryLabel: 'Energy',
    conversionFactor: 0.80,
    unit: 'kWh',
    unitLabel: 'Kilowatt Hours (kWh)',
    defaultQuantity: 8,
    iconName: 'Zap',
    color: '#d97706', // amber-600
    bgLight: 'bg-amber-50 text-amber-700 border-amber-200',
    bgDark: 'dark:bg-amber-950/40 dark:text-amber-300 dark:border-amber-800',
    borderColor: 'border-amber-500',
    description: 'Grid electricity consumption (0.80 kg CO₂ / kWh)',
  },
  veg_meal: {
    type: 'veg_meal',
    label: 'Vegetarian Meal',
    category: 'food',
    categoryLabel: 'Food',
    conversionFactor: 0.50,
    unit: 'meals',
    unitLabel: 'Number of Meals',
    defaultQuantity: 1,
    iconName: 'Salad',
    color: '#16a34a', // green-600
    bgLight: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    bgDark: 'dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800',
    borderColor: 'border-emerald-500',
    description: 'Plant-based or vegetarian meal (0.50 kg CO₂ / meal)',
  },
  non_veg_meal: {
    type: 'non_veg_meal',
    label: 'Non-Vegetarian Meal',
    category: 'food',
    categoryLabel: 'Food',
    conversionFactor: 2.00,
    unit: 'meals',
    unitLabel: 'Number of Meals',
    defaultQuantity: 1,
    iconName: 'Beef',
    color: '#e11d48', // rose-600
    bgLight: 'bg-rose-50 text-rose-700 border-rose-200',
    bgDark: 'dark:bg-rose-950/40 dark:text-rose-300 dark:border-rose-800',
    borderColor: 'border-rose-500',
    description: 'Meat/poultry-inclusive meal (2.00 kg CO₂ / meal)',
  },
};

export interface CarbonActivity {
  id: string;
  type: ActivityType;
  category: ActivityCategory;
  quantity: number;
  emissionsKg: number;
  timestamp: string; // ISO 8601
  note?: string;
}

export type DateRangePreset = 'all' | 'today' | 'this_week' | 'this_month' | 'custom';

export interface FilterState {
  category: 'all' | ActivityCategory;
  dateRange: DateRangePreset;
  customStartDate?: string;
  customEndDate?: string;
  searchQuery?: string;
}

export interface WeeklyTargetSettings {
  targetKg: number;
  updatedAt: string;
}

export type BadgeTier = 'bronze' | 'silver' | 'gold' | 'platinum' | 'diamond' | 'legendary';

export interface StreakBadge {
  id: string;
  name: string;
  tier: BadgeTier;
  requiredWeeks: number;
  description: string;
  icon: string;
  isUnlocked: boolean;
  unlockedAtStreak?: number;
}

export interface WeekStreakRecord {
  weekOffset: number; // 0 = current week, 1 = previous week, etc.
  startDate: string;
  endDate: string;
  label: string; // e.g. "Sep 8 – Sep 14"
  totalEmissionsKg: number;
  targetKg: number;
  isUnderLimit: boolean;
  isCurrentWeek: boolean;
  activitiesCount: number;
  status: 'passed' | 'failed' | 'in_progress';
}

export interface WeeklyStreakSummary {
  currentStreak: number;
  completedStreak: number;
  isCurrentWeekUnderLimit: boolean;
  currentWeekKg: number;
  currentWeekRemainingKg: number;
  longestStreak: number;
  recentWeeks: WeekStreakRecord[];
  badges: StreakBadge[];
  nextBadge: StreakBadge | null;
  weeksUntilNextBadge: number;
}

export interface MonthTrendData {
  monthIndex: number; // 0..11
  monthShort: string; // "Jan", "Feb", ...
  monthFull: string; // "January", ...
  year: number;
  totalKg: number;
  travelKg: number;
  energyKg: number;
  foodKg: number;
  activityCount: number;
  budgetKg: number;
  isCurrentMonth: boolean;
  isFutureMonth: boolean;
  varianceFromBudgetKg: number; // difference: totalKg - budgetKg
  changeFromPrevMonthKg: number | null;
  changeFromPrevMonthPercent: number | null;
}

export interface QuarterlyTrendData {
  quarter: 'Q1' | 'Q2' | 'Q3' | 'Q4';
  label: string; // "Q1 (Jan–Mar)"
  totalKg: number;
  travelKg: number;
  energyKg: number;
  foodKg: number;
  monthlyAverageKg: number;
  budgetKg: number;
}

export interface AnnualMonthlyTrendSummary {
  year: number;
  months: MonthTrendData[];
  quarterly: QuarterlyTrendData[];
  totalYearKg: number;
  activeMonthsCount: number;
  monthlyAverageKg: number;
  peakMonth: MonthTrendData | null;
  lowestActiveMonth: MonthTrendData | null;
  annualBudgetKg: number;
  availableYears: number[];
  seasonalityInsight: string;
}

export type ThemePreference = 'light' | 'dark' | 'system';
